# RescueLoop Three-Package Fast-Track Bundle

Execution order: Workspace 03 → Workspace 04 → Workspace 05. Use `RescueLoop_Zai_Three_Package_Fast_Track_Prompt.md`.
