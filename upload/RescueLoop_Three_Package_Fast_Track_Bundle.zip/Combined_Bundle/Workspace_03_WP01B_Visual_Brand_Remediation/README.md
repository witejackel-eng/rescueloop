# RescueLoop Workspace 03 — WP-01B Visual Brand Remediation

This package closes the gap between **brand assets existing in code** and the product actually looking and feeling recognisably RescueLoop.

## Repository target
- Repository: `witejackel-eng/rescueloop`
- Branch: `integration/rescueloop-v1`
- Do not merge to `main`.
- All new commits must use `witejackel-eng <291486779+witejackel-eng@users.noreply.github.com>`.

## Why this package exists
The current branch contains a Closing Signal mark, favicon files, metadata code, Open Graph images, and brand tokens. The visible interface still fails acceptance: the header is crowded, the hero is obscured, the mark is too small, the old orbit/radar language dominates, copy remains broad, and the new work has not reached a READY Vercel preview.

## Locked positioning
- Category: **Activation rescue for Whop creators**
- Headline: **Close the loop before they leave.**
- Promise: **Find who needs help. Approve the right message. See what changed.**
- Trust: **Nothing sends without your approval.**
- Primary CTA: **Explore the interactive demo**
- Secondary CTA: **See the student experience**

## Completion definition
WP-01B is complete only when the Vercel preview is READY, header and hero pass visual QA, favicon/manifest/OG/Twitter metadata are proven from deployed HTML, screenshot evidence is uploaded, strict CI remains green, and WP-02 is not mixed into the commit.
