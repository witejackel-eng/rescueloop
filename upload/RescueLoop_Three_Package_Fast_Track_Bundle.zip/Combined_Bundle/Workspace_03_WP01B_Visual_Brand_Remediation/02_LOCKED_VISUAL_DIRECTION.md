# Locked Visual Direction

**Closing Signal** represents a creator noticing an unfinished learning loop and closing it through respectful support.

## Visual grammar
- incomplete circular path;
- signal node;
- intervention bridge;
- completed/returned state;
- warm cream canvas;
- near-black typography;
- recovery green for useful motion;
- amber only for attention;
- red only for true failure.

## Avoid
Generic AI gradients, glassmorphism, cyber-security style, trading-terminal density, ambulance imagery, giant logo repetition, excessive floating cards, perpetual movement, and unexplained radar/orbit diagrams.

## Hero narrative
1. signal appears;
2. loop remains open;
3. creator reviews and approves;
4. support is sent;
5. progress resumes;
6. loop closes;
7. evidence remains visible.
