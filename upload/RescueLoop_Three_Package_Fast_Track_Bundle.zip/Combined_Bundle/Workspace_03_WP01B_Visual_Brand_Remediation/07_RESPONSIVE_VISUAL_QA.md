# Responsive and Visual QA

Required viewports: 390×844, 768×1024, 1024×768, 1180×820, 1280×800, 1366×768, 1440×900, 1600×900.

Capture homepage top, scrolled header, mobile menu, final CTA, browser tab/favicon, and OG image.

Reject on overlap, unexpected wrapping, header-covered hero, horizontal scroll, missing CTA, unreadable logo, continuous reduced-motion animation, or incorrectly cropped social image.
