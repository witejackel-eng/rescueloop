# Current-State Visual Audit

## Header defects
- Brand, navigation, and CTA compete for space.
- “RescueLoop Product” reads as one malformed phrase.
- “Private pilot” wraps.
- The visual centre is wrong.
- The breakpoint switches too late.
- The fixed header overlaps the headline.

## Brand defects
- Closing Signal is only a tiny icon.
- The old orbit/radar graphic dominates.
- Recovery green does not communicate signal → support → return.
- No memorable brand moment exists.

## Content defects
- Category is not clear in the first viewport.
- Supporting copy is too broad.
- The old kinetic headline competes with the locked positioning.

## Interaction defects
- Motion is decorative rather than explanatory.
- The marquee competes with the hero.
- No open-loop-to-closed-loop transition exists.

## Deployment defects
- Production still serves the older `main` implementation.
- Integration previews are blocked by unverified author identity.
- Favicon and social metadata are not proven on a READY preview.
