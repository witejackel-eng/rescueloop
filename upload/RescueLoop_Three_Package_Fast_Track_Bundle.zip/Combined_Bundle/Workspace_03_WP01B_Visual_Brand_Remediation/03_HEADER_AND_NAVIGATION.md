# Header and Navigation Contract

## Desktop centre navigation
Use exactly:
- Product
- How it works
- Student experience
- Pricing

Move Safety, FAQ, legal, and private pilot out of the centre navigation. Keep one CTA: **Explore demo**.

## Layout
Three protected regions: brand, navigation, CTA. Brand and CTA never shrink; centre region collapses.

## Breakpoints
- 1366+ full desktop
- 1180–1365 compact desktop
- below 1180 mobile/compact unless measured content fits cleanly

## Acceptance
No wrapping, no horizontal overflow, no collision, hero begins below header, anchor targets use `scroll-margin-top`, focus follows visual order, Escape restores focus, and CTA remains visible from 1180 through 1600.
