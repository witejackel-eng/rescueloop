# Hero and First Viewport

Eyebrow: `Activation rescue for Whop creators`

Headline: `Close the loop before they leave.`

Supporting line: `Find who needs help. Approve the right message. See what changed.`

Trust line: `Nothing sends without your approval.`

Primary CTA: `Explore the interactive demo`

Secondary CTA: `See the student experience`

Disclosure: `Interactive demonstration. No messages are sent and no customer data is connected.`

## Composition
Desktop: copy left, Closing Signal product visual right. The full headline must be visible at 1366×768. Mobile stacks copy before visual and uses simplified motion.

## Motion
Animate signal appearance, approval bridge, return, and loop closure. Reduced motion removes translation, blur, and continuous movement. Remove or simplify the marquee when it competes.
