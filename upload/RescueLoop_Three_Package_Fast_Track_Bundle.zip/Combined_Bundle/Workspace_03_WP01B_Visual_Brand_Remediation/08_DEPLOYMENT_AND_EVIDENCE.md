# Deployment and Evidence

Commit as `witejackel-eng <291486779+witejackel-eng@users.noreply.github.com>`. Do not rewrite history.

Trigger a Preview Deployment from `integration/rescueloop-v1`. It must reach `READY`; do not promote to production.

Upload CI artifact: `rescueloop-wp01b-visual-evidence` containing screenshots, metadata dump, endpoint report, and before/after index.

Report commit SHA, author, CI run, Vercel deployment ID/URL, screenshots, viewport results, metadata, asset endpoints, and limitations.
