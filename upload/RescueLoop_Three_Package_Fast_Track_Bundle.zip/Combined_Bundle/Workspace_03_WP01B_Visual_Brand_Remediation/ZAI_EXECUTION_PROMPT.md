# Zai Execution Prompt — Workspace 03 / WP-01B

Execute directly in `witejackel-eng/rescueloop` on `integration/rescueloop-v1`. Configure Git as `witejackel-eng <291486779+witejackel-eng@users.noreply.github.com>`. Do not return a plan-only response.

Read every package file, inspect the homepage, `floating-nav.tsx`, logo module, root metadata, brand assets, Playwright tests, and Vercel project.

Implement the complete remediation: rebuild header, recompose hero around Closing Signal, apply locked copy, verify favicon/manifest/OG/Twitter metadata, capture visual evidence, add strict responsive/metadata tests, update ledger, push a verified-author commit, and wait for a READY Vercel preview.

Do not begin WP-02, merge to main, weaken tests, use fake claims, expose secrets, or preserve the old orbit merely because it exists.

Commit: `fix(brand): complete visual identity and preview deployment`

Return full SHA, author, CI run, Vercel deployment ID/URL/status, artifact filenames, viewport results, metadata dump, endpoint report, exact test counts, and limitations.
