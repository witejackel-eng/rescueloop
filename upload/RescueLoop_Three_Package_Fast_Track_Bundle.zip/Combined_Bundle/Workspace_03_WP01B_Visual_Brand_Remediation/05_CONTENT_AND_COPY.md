# Content and Copy Contract

The first viewport must answer who the product is for, which members it finds, what the creator does, what the student receives, how outcomes are observed, and whether anything sends automatically.

Use: member, student, needs help, never started, lost momentum, review, approve, support, returned, observed outcome, manual approval.

Avoid on student surfaces: risk, churn, revenue rescue, cancellation probability, target, conversion, retention pressure.

Homepage order: Hero → Detect/Review/Support/Observe → Safety → Student experience → Outcome evidence → Pricing → FAQ/resources → Final CTA.
