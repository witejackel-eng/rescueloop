# Acceptance Gates

WP-01B passes only when:
- header has no collision/wrapping;
- hero is not hidden;
- Closing Signal drives the composition;
- first viewport communicates category, action, outcome, control;
- mobile is clean;
- strict CI passes;
- brand endpoints return 200 with correct content types;
- deployed metadata is correct;
- reduced motion is tested;
- screenshot artifact exists;
- Vercel preview is READY;
- ledger is updated;
- WP-02 was not started.
