# Metadata, Favicon, and Social Verification

Verify deployed HTTP 200 and content types for:
`/brand/favicon.svg`, `/brand/favicon-16.png`, `/brand/favicon-32.png`, `/brand/favicon-48.png`, `/brand/apple-touch-icon.png`, `/brand/icon-192.png`, `/brand/icon-512.png`, `/brand/whop-app-icon-512.png`, `/brand/og-default-1200x630.png`, `/brand/twitter-default-1200x630.png`, `/brand-manifest.json`.

Generated HTML must include canonical title, description, icons, Apple touch icon, manifest, `og:image`, `twitter:image`, and `twitter:card=summary_large_image` with environment-safe absolute URLs.

Capture a browser-tab/favicon image, direct OG image, and homepage `<head>` dump.
