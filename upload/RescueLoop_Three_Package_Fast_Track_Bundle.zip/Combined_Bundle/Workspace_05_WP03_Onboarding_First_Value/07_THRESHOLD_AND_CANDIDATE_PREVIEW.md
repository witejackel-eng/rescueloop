# Threshold and Candidate Preview

Threshold remains configurable and the default is labelled as a hypothesis. Before saving, show candidate count, percentage, samples, cooldown/safety implications, and effect on current state.

Preview shows member, course/product, membership/payment state, start/progress evidence, inactivity, eligibility reason, unknown evidence, and suppression/cooldown. Previewing never generates or sends a message.
