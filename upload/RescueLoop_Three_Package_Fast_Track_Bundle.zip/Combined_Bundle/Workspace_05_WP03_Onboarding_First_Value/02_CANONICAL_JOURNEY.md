# Canonical Onboarding Journey

0. Entry at `/dashboard/[companyId]`: verify Whop token, company admin, app config, onboarding state.
1. Connection: show connected state, company, permissions, provider check, safe retry.
2. Mapping: list real courses/products, member counts when known, zero-course guidance, refresh, support path.
3. First sync: company/product references → memberships → members → course students → lessons/progress → reconciliation → candidate evaluation. Persist stages and resume after leaving.
4. Threshold: configure inactivity threshold and preview candidate count before activation.
5. Candidate preview: show evidence, unknowns, suppression/cooldown, and “nothing sent”.
6. First value: route to `/dashboard/[companyId]/rescue-queue` with first candidate or honest zero-candidate state.
