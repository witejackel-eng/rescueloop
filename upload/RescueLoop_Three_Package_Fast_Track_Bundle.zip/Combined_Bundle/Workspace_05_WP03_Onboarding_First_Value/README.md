# RescueLoop Workspace 05 — WP-03 Onboarding and First Value

This package makes RescueLoop usable by a new Whop creator without developer assistance.

Begin only after WP-01B visual acceptance and WP-02 interaction foundation pass.

Repository: `witejackel-eng/rescueloop`  
Branch: `integration/rescueloop-v1`  
Commit identity: `witejackel-eng <291486779+witejackel-eng@users.noreply.github.com>`

Use the existing mature Whop, Prisma, sync, job, safety, and connected-route architecture. Do not send real student messages during onboarding.

## First value
A creator enters through Whop, passes admin/permission checks, maps a course/product, completes a truthful first sync, configures inactivity threshold, previews candidates or an honest zero state, and reaches the Rescue Queue in 5–10 minutes for a correctly configured test company.
