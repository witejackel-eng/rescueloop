# Zai Execution Prompt — Workspace 05 / WP-03

Execute immediately after Workspace 04 passes in `witejackel-eng/rescueloop` on `integration/rescueloop-v1`. Commit as `witejackel-eng <291486779+witejackel-eng@users.noreply.github.com>`. Do not return a plan-only response.

Deliver install-to-first-value onboarding using the mature Whop, Prisma, sync, reconciliation, usage, safety, and job architecture. Consolidate rather than creating parallel systems.

Implement canonical `/dashboard/[companyId]` routes, compatibility redirects, authorization, diagnostics, real course mapping, zero-course state, resumable first sync, threshold/candidate preview, first-value and zero-candidate completion, fixture/connected separation, privacy-safe analytics, safe diagnostic IDs, tests, and evidence.

Do not send real notifications, expose secrets, reset/destructively migrate the DB, or use fixtures in connected routes. Stop before any action that could contact a real student.

Use only an explicitly controlled Whop test company. Capture access, permission failure, mapping, zero-course, sync/resume, threshold, candidate preview, zero-candidate, and Rescue Queue evidence. Upload `rescueloop-wp03-onboarding-evidence`.

Commit: `feat(onboarding): deliver install-to-first-value Whop journey`

Push, run strict CI, wait for READY Vercel preview, update ledger, and stop before WP-04. Return SHA, CI, preview, test counts, controlled Whop result, time-to-first-value, artifact, owner actions, and blockers.
