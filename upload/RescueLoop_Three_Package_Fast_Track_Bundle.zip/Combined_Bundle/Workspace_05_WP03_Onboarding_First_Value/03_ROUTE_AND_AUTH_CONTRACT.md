# Route and Authentication Contract

Canonical connected routes live under `/dashboard/[companyId]`: onboarding, overview, rescue-queue, students, responses, playbooks, insights, value, activity, sync, usage, settings.

Older `/companies/[companyId]` paths must redirect or delegate safely; do not maintain two systems.

Every connected request validates Whop token, company access, admin access, tenant identity, and server-side entitlement where relevant. Never trust client company ID alone. Connected routes never silently render fixtures.
