# Fixture and Connected Separation

Fixture mode is visibly simulated, makes no real provider calls or notifications, and supports public exploration.

Connected mode uses real authorization/database/provider results, never falls back to fixture data, exposes stale/empty/error states, keeps secrets server-side, and is noindex.

Tests must fail if a connected route silently renders fixture data.
