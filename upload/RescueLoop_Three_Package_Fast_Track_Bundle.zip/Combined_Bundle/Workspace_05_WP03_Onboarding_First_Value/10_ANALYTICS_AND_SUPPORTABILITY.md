# Analytics and Supportability

Allowlist events: onboarding_started, access_verified, permission_missing, mapping_viewed, mapping_saved, sync_started, sync_stage_completed, sync_failed, threshold_previewed, threshold_saved, candidate_previewed, first_value_reached, zero_candidate_completed, onboarding_abandoned.

Never send email, message body, student free text, raw provider payload, secrets, or sensitive evidence.

Support logs may include safe diagnostic ID, authorised company ID, stage/error category, retry count, timestamps, and provider request ID.
