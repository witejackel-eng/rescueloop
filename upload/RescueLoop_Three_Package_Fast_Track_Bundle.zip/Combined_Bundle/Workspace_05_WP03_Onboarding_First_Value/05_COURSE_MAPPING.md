# Course and Product Mapping

List real provider results with stable IDs, member counts when trustworthy, refresh, duplicate prevention, previous mapping preservation on provider failure, explicit confirmation before remapping, and audit events.

Zero-course state explains likely causes, required permissions, refresh, diagnostic test, support path, and confirms no messages or student changes occurred.
