# First-Value Completion

Complete onboarding only when access, mapping, first sync, threshold, candidate evaluation, and queue/zero state are finished.

Use one restrained Closing Signal confirmation. Show what connected, what scanned, candidate count, safety exclusions, next action, and “Nothing has been sent.”

Zero candidates is success: explain scan completion, threshold option, data freshness, and what RescueLoop watches next.
