# Current Onboarding Audit

Existing foundation: company onboarding form, Whop admin auth, course/product fetching, sync engine/checkpoints, reconciliation records, usage infrastructure, fixture demo, and connected company routes.

The gap is one proven install-to-first-value journey.

Risks: old `/companies/[companyId]` routes, fixture/connected confusion, unhelpful zero-course/zero-candidate states, unclear permission failures, long-running first sync, uncertain resume behaviour, previously observed zero course results, and no trustworthy first-value analytics.
