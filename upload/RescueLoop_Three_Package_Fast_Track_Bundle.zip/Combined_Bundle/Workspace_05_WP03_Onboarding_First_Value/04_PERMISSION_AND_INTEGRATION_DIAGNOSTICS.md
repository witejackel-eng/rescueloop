# Permission and Integration Diagnostics

Support configured/connected, missing API key/app ID/company ID, invalid token, non-admin, missing scopes, Whop temporary failure, rate limit, no courses, database unavailable, and stale connection.

Every failure states what failed, whether data changed, exact safe next action, retry safety, and whether owner/admin help is needed. Never print secrets. Generate a safe diagnostic ID and structured log without sensitive payloads.
