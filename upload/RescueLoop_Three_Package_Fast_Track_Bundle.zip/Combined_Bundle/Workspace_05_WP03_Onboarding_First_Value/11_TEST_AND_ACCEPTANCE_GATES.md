# Test and Acceptance Gates

Automate dashboard authorization, non-admin rejection, missing scopes, mapping, duplicate prevention, zero-course state, resumable/idempotent sync, failed-stage retry, threshold preview, candidate preview, zero-candidate success, fixture separation, legacy redirects, analytics allowlist, and proof that onboarding makes no notification provider call.

Controlled Whop test: enter dashboard, verify admin, list courses, map, sync, set threshold, preview, reach queue.

WP-03 passes only when the journey completes in 5–10 minutes for a configured test company, no developer intervention is required, zero states are clear, sync resumes, no message is sent, Vercel preview is READY, evidence exists, CI passes, and ledger is updated.
