# First Sync and Resume

Require durable background execution, persisted stages/checkpoints, idempotent ingestion, bounded pagination, visible progress, leave-and-return, failed-stage retry, stale-run detection, reconciliation, and truthful partial-data state.

Show current/completed stages, records processed, last provider response time, failure, retry, and reassurance. Do not invent percentage when totals are unknown.
