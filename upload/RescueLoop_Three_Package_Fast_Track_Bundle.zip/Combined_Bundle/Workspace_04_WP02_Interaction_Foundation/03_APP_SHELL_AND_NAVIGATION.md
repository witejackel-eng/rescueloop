# App Shell and Navigation

Preserve shell, company/course context, navigation state, and stable top controls across routes. Use regional skeletons instead of full-screen flashes. Errors render inside the content region. Browser back restores reasonable context. Deep links open the correct inspector where supported.

Navigation must expose current route, support keyboard/screen readers, close mobile sheets on navigation, and share one route registry with the command palette.
