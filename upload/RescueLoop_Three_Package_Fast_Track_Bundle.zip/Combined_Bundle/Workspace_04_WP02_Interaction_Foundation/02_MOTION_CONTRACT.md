# Motion Contract

Durations: instant 80ms; press 120ms; micro 160ms; standard 240ms; panel 320ms; route 360ms; reveal 520ms; hero 820ms maximum; first-value confirmation 480ms and rare.

Rules: press feedback next frame; local state visible within 100ms when safe; no animation delays tasks; no hover layout shift; no scroll-jacking; no custom cursor; no continuous dense-screen motion; pause offscreen/hidden motion; one library owns a transform; reduced motion removes translation, blur, parallax, and repetition.

Closing Signal may mark approval, scheduling, observed return, and first value—not every click.
