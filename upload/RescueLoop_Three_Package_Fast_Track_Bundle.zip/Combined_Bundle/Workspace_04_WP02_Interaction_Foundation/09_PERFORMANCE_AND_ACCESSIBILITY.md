# Performance and Accessibility

Avoid full page rerenders, unbounded lists, unnecessary client components, duplicate motion owners, and layout-shifting skeletons. Lazy-load charts/editors/inspectors and virtualize only when justified.

Require visible focus, logical tab order, focus restoration, async live regions, dialog semantics, table semantics, chart text summaries, no color-only state, 200% reflow, reduced motion, Escape behaviour, and no keyboard traps.
