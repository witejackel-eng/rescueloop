# Keyboard and Command Palette

Queue: Arrow Up/Down changes active row; Enter opens inspector; Escape closes; Space toggles selection only on selectable rows; action shortcuts never fire in inputs/editors; active row is programmatically exposed.

Command palette: one registry for routes and safe actions; search members/playbooks/settings; never expose internal routes to creators; disable unavailable actions with reason; preserve company context; restore trigger focus; document shortcuts.
