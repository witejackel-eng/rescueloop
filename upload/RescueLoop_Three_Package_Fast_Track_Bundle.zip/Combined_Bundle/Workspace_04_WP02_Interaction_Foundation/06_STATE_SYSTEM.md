# Shared State System

Every primary screen implements loading, empty, populated, partial, stale, permission error, network error, server error, plan limit, paused, reduced motion, and mobile layout.

Each state answers: what happened, whether data is incomplete, what can be done now, whether retry is safe, and whether an action already occurred.
