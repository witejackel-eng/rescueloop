# Mutations, Undo, and Feedback

Every mutation supports idle, pressed, pending, success, failure, safe retry, duplicate/idempotent response, permission denied, plan limit, and paused/suppressed states.

Optimistic updates require deterministic rollback and visible pending state. Undo is required for reversible actions such as dismissing a queue item, filter changes, playbook pause, and bulk deselection. Never offer fake undo after irreversible provider submission.

Use truthful labels: saved, scheduled, queued, provider accepted, suppressed, failed, retrying. Never claim delivered without evidence.
