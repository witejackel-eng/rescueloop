# Zai Execution Prompt — Workspace 04 / WP-02

Execute immediately after Workspace 03 passes in `witejackel-eng/rescueloop` on `integration/rescueloop-v1`. Commit as `witejackel-eng <291486779+witejackel-eng@users.noreply.github.com>`. Do not return a plan-only response.

Implement stable app shell, route pending states, drawers/sheets, focus restoration, queue keyboard operation, command registry, truthful mutation feedback, rollback, genuine undo, complete loading/empty/stale/error/plan-limit states, mobile and local Whop-frame verification, reduced motion, and interaction performance cleanup.

Preserve brand, backend rules, provider behaviour, manual approval, and safety controls. Do not begin onboarding, billing, or real sending. Do not weaken tests or replace native scrolling.

Capture evidence for route transitions, keyboard queue, focus restoration, mutation feedback/undo, mobile sheet, reduced motion, and iframe harness. Upload `rescueloop-wp02-interaction-evidence`.

Commit: `feat(interactions): establish RescueLoop interaction operating system`

Push, wait for strict CI and READY Vercel preview, update ledger, and stop before WP-03. Return SHA, CI, deployment, test counts, artifact, state coverage, accessibility results, and limitations.
