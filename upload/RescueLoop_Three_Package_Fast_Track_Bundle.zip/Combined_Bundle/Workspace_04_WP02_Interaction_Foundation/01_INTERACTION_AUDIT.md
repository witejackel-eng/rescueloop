# Interaction Audit

The repository already has motion tokens, command palette, queue keyboard handling, drawers, sheets, toasts, and responsive shells. The missing work is consistency and proof.

Likely gaps: multiple motion owners, shell remounting, inconsistent focus restoration, drawers losing row context, no consistent undo/rollback, uneven loading/stale/partial/error/plan-limit states, inconsistent mobile semantics, incomplete reduced motion, undiscoverable keyboard shortcuts, no shared live-region contract, no evidence artifact, and unverified Whop iframe behaviour.
