# Mobile and Whop Embedded Context

Mobile: aim for 44×44 targets, keep bottom nav from covering actions, respect safe areas, remain usable with on-screen keyboard, deliberately adapt tables, and keep the queue usable.

Whop frame: verify height, double scrollbars, focus, sticky-header collision, external links, auth redirects, and common embedded widths. Build a local frame harness when real embedding is unavailable and retain real-Whop verification as tracked debt.
