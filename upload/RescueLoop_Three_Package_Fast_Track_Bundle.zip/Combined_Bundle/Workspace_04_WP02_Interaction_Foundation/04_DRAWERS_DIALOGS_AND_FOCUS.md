# Drawers, Dialogs, and Focus

Desktop inspector: open from stable row, keep source visible, preserve selected identity, close with Escape, restore focus, support next/previous, encode selected item in URL when safe.

Mobile: use safe-area-aware sheet, reachable primary action, no nested-scroll trap, restore focus.

Destructive confirmations must state consequences, avoid destructive default focus, and require explicit confirmation.
