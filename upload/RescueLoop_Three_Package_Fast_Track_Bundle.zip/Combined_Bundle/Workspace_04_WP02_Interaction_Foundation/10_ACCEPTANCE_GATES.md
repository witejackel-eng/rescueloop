# Acceptance Gates

WP-02 passes only when shell stays stable, queue works by keyboard, drawers restore focus, mobile sheets work, reversible actions offer real undo, failed optimistic updates rollback, primary screens have the complete state matrix, reduced motion removes nonessential movement, required viewports have no overflow, local Whop-frame harness has no major scroll defect, evidence is uploaded, strict CI and Vercel preview are green, and WP-03 is not mixed into the commit.
