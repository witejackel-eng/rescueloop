# RescueLoop WP-01 — Brand Foundation

## Purpose

This package is the implementation contract for **Work Package 01: Brand Foundation** on `witejackel-eng/rescueloop`.

It is designed for the canonical branch:

```text
integration/rescueloop-v1
```

Repository state used for this package:

```text
Observed branch head: 1e05bc0422633171504e362e04d6b8db2585c772
Observed date: 2026-08-06
```

The implementer must re-check the remote branch before editing. This package does not assume that the observed SHA is still current.

## Work-package boundary

WP-01 establishes one recognizable, production-safe RescueLoop identity across:

- browser and operating-system surfaces;
- Whop listing and installed-app surfaces;
- public marketing;
- demo workspace;
- connected creator workspace;
- student experience;
- internal operations;
- social sharing and link previews;
- product screenshots and future launch material.

WP-01 does **not** redesign workflows, rebuild the dashboard, introduce new interaction patterns, change pricing, alter database behavior, send notifications, or begin WP-02 motion work.

## Required implementation outcome

After this work package, RescueLoop must have:

1. One canonical Closing Signal mark.
2. One canonical React logo component family.
3. One source of brand tokens.
4. One metadata and icon strategy compatible with the current Next.js App Router.
5. One naming and microcopy dictionary.
6. A protected/development-only Brand QA route.
7. Consistent identity across every route group.
8. Automated checks that prevent duplicate marks, missing assets, off-system colors, metadata regressions, and inaccessible logo use.
9. A screenshot-ready visual frame for later Whop marketplace work.
10. A fully green strict CI run before the stage is marked complete.

## Start order

Read in this order:

1. `01_CURRENT_REPOSITORY_BRAND_AUDIT.md`
2. `02_BRAND_NORTH_STAR.md`
3. `03_CLOSING_SIGNAL_LOGO_SYSTEM.md`
4. `04_CANONICAL_COMPONENT_AND_ASSET_ARCHITECTURE.md`
5. `05_COLOR_TYPE_SPACING_AND_TOKEN_MIGRATION.md`
6. `06_METADATA_FAVICON_OG_AND_MANIFEST.md`
7. `07_ROUTE_GROUP_APPLICATION_MATRIX.md`
8. `08_POSITIONING_NAMING_AND_MICROCOPY.md`
9. `09_BRAND_QA_ROUTE_AND_AUTOMATED_CHECKS.md`
10. `10_ACCESSIBILITY_OPTICAL_AND_PERFORMANCE_QA.md`
11. `11_SCREENSHOT_AND_SOCIAL_FRAME_SYSTEM.md`
12. `12_IMPLEMENTATION_SEQUENCE.md`
13. `13_ACCEPTANCE_GATES.md`
14. `14_HANDOFF_EVIDENCE_FORMAT.md`

Machine-readable contracts are in `machine/`. Production-starting assets are in `assets/brand/`.
