# Sources and Current Standards

Validate these sources again at execution time because platform conventions can change.

## Next.js

- App icon metadata files: https://nextjs.org/docs/app/api-reference/file-conventions/metadata/app-icons
- Open Graph/Twitter image metadata files: https://nextjs.org/docs/app/api-reference/file-conventions/metadata/opengraph-image
- Web app manifest: https://nextjs.org/docs/app/api-reference/file-conventions/metadata/manifest
- Metadata overview: https://nextjs.org/docs/app/getting-started/metadata-and-og-images

## Whop

- Whop App Store overview: https://docs.whop.com/whop-apps/whop-app-store
- App object/icon behavior: https://docs.whop.com/api-reference/apps/app

## Accessibility

- WCAG 2.2 AA is the minimum target.

No source permits copying Apple’s trade dress. “Apple-level” means disciplined clarity, continuity, performance, accessibility, and restraint—not visual imitation.
