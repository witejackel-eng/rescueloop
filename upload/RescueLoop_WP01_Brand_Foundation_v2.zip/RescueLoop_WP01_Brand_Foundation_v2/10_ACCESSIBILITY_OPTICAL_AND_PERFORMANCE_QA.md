# Accessibility, Optical, and Performance QA

## Accessibility

- Text contrast: WCAG 2.2 AA minimum.
- Mark must not be the only way to identify a navigation destination.
- Standalone meaningful mark requires an accessible name.
- Decorative mark must be `aria-hidden`.
- Status cannot rely on color alone.
- Focus rings remain visible on cream, white, green, and ink backgrounds.
- Wordmark must remain readable at 200% zoom.
- Brand QA route must be keyboard navigable.

## Optical quality

Inspect at 100%, 125%, 150%, and 200% browser scaling.

Check:

- mark gap and node separation;
- vertical alignment with wordmark;
- perceived rather than geometric centering;
- weight consistency at 16–32 px;
- lockup spacing in compact navigation;
- anti-aliasing on Windows and macOS/browser screenshots;
- no clipping in Whop iframe/sidebar contexts.

## Performance budgets

- No client-side JavaScript solely to render the logo.
- SVG mark target: under 8 KB minified.
- Favicon assets: under 50 KB each.
- 512 icon target: under 250 KB where quality permits.
- OG image target: under 500 KB; hard ceiling below Next.js file limit.
- Use `next/font`; do not add runtime font requests or commit font binaries.
- Do not ship brand QA code into customer production bundles when avoidable.
- Avoid large inline base64 assets.

## Cross-surface matrix

Test:

- Chrome/Edge on Windows;
- Safari/mobile rendering where available;
- 320, 375, 390, 768, 1024, 1440 widths;
- Whop embedded/dashboard context;
- browser tab in light and dark browser chrome;
- link previews where tooling permits.
