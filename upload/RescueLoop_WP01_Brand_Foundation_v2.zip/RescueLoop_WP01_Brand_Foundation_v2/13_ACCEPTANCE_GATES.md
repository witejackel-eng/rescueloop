# WP-01 Acceptance Gates

WP-01 is complete only when every blocking item passes.

## Identity

- [ ] Closing Signal is the only production logo mark.
- [ ] Mark remains clear at 16 px.
- [ ] Primary, mono, reversed, micro, tile, and lockup variants exist.
- [ ] No duplicate inline logo geometry remains.
- [ ] Wordmark is live text in application UI.

## Assets

- [ ] Favicon 16/32/48 exports exist and validate.
- [ ] Apple touch icon exists at 180×180.
- [ ] App icons exist at 192×192 and 512×512.
- [ ] Whop icon exists at 512×512.
- [ ] Social avatar exists.
- [ ] OG and Twitter images exist at 1200×630 with alt text.
- [ ] Raster exports are generated from canonical source.

## Metadata

- [ ] Root metadata is complete and environment-safe.
- [ ] Manifest validates.
- [ ] Public routes have deliberate canonical metadata.
- [ ] Connected/internal/student-token routes cannot leak private details.
- [ ] Private/demo routes use deliberate index policy.

## Tokens and typography

- [ ] Existing palette is consolidated, not duplicated.
- [ ] No new primary font is introduced.
- [ ] Recovery green remains semantic.
- [ ] No off-system production brand colors.
- [ ] Typography hierarchy is documented and implemented.

## Route groups

- [ ] Marketing uses full identity.
- [ ] Demo is clearly labelled.
- [ ] Creator workspace uses compact identity.
- [ ] Student experience uses safe, quiet identity.
- [ ] Internal operations shows Internal context.
- [ ] Legal/support surfaces remain restrained and credible.

## Copy

- [ ] Canonical naming dictionary is used.
- [ ] Student-facing forbidden terms return zero production matches.
- [ ] `delivered` is not used for provider acceptance.
- [ ] No generic AI hype or unsupported claims are added.

## Accessibility and performance

- [ ] Meaningful marks are labelled; decorative marks are hidden.
- [ ] Contrast passes WCAG 2.2 AA.
- [ ] Focus remains visible on all brand backgrounds.
- [ ] Asset budgets pass.
- [ ] No font files are committed.
- [ ] No client JavaScript is required solely for logo rendering.

## QA and release

- [ ] Brand QA route exists and is protected.
- [ ] Brand-specific automated checks pass.
- [ ] Strict existing CI remains green.
- [ ] Production build passes.
- [ ] Desktop/mobile/Whop iframe screenshots are captured.
- [ ] Execution ledger contains exact evidence.
- [ ] One scoped WP-01 commit is pushed.
- [ ] WP-02 has not started.
