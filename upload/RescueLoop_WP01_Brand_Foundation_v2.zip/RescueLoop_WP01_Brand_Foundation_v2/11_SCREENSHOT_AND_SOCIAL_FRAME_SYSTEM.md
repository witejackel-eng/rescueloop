# Screenshot and Social Frame System

This stage does not create the final marketplace campaign, but it must make the product screenshot-ready.

## Marketplace screenshot frame

Every screenshot should eventually use:

- 24 px outer frame;
- one clear headline;
- one product proof;
- one restrained annotation;
- consistent browser/window treatment;
- real data or visibly labelled demo data;
- no fabricated metrics or testimonials.

## Five future proof statements

1. See who paid but never started.
2. Review every message before it sends.
3. Understand the evidence behind every signal.
4. See who returned after support.
5. Measure value without inflated attribution.

## Social frame

- 1200×630 master.
- Cream-to-surface background.
- Closing Signal mark and wordmark.
- Central promise.
- Category line.
- Signal-to-return trajectory.
- No customer logos until permission exists.
- No security badge unless certification exists.
- No fake usage/revenue numbers.

## Screenshot readiness acceptance

- Product shell logo is stable at all viewport widths.
- Demo labels cannot be cropped out.
- No temporary debug controls.
- Brand colors reproduce consistently.
- Browser and OG previews show the same identity.
