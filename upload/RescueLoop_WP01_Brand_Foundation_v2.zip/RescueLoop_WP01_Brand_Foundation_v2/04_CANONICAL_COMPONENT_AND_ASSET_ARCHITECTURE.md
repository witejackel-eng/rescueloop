# Canonical Component and Asset Architecture

## Target code structure

```text
src/components/brand/
  rescue-loop-logo.tsx
  brand-signature.tsx
  brand-context.tsx
  index.ts

src/brand/
  contract.ts
  tokens.ts
  copy.ts
  metadata.ts

public/brand/
  mark-primary.svg
  mark-mono.svg
  mark-reversed.svg
  mark-micro.svg
  favicon.svg
  favicon-16.png
  favicon-32.png
  favicon-48.png
  apple-touch-icon.png
  icon-192.png
  icon-512.png
  whop-app-icon-512.png
  social-avatar-512.png
  og-default-1200x630.png
  twitter-default-1200x630.png
```

The implementer may adjust filenames to fit existing conventions, but there must be one obvious canonical source.

## Component API

Recommended API surface:

```tsx
<RescueLoopMark size="sm" variant="primary" decorative />
<RescueLoopMark size={32} variant="reversed" label="RescueLoop" />
<RescueLoopLogo context="marketing" />
<RescueLoopLogo context="workspace" compact />
<BrandSignature context="student" />
```

Do not create a different SVG mark in each header.

## Context behavior

### Marketing

Full mark + wordmark; editorial spacing; category line optional.

### Demo

Full identity plus a visible “Demo” label. Demo state must never masquerade as connected data.

### Connected creator workspace

Compact mark + wordmark. Company context is secondary. Avoid marketing slogans in the operational shell.

### Student experience

Small, reassuring brand signature. No revenue, risk, churn, rescue-target, or conversion language.

### Internal operations

Mark + wordmark + explicit `Internal` badge. Internal surfaces must never be confused with customer-facing UI.

## Asset source policy

- SVG is canonical for vector marks.
- PNG exports are generated from canonical SVGs.
- Do not manually edit generated PNGs.
- Do not embed large base64 icons in application CSS.
- Keep OG and marketplace composition source files versioned.
- Record dimensions, safe area, background, and intended use in `machine/asset_manifest.csv`.

## Duplicate-removal policy

Before deleting any existing logo file:

1. Find every import and usage.
2. Replace usage with the canonical component.
3. Run typecheck and E2E.
4. Confirm no public URL still references the old asset.
5. Delete only after successful replacement.
