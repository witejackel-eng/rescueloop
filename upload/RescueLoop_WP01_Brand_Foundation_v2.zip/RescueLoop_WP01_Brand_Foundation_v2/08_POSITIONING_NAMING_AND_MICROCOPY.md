# Positioning, Naming, and Microcopy

## Homepage hierarchy

Eyebrow:

> Activation rescue for Whop creators

Hero:

> Close the loop before they leave.

Support:

> RescueLoop finds paying members who never started, prepares respectful outreach for your approval, and shows what changed after you reached out.

Primary CTA:

> Install on Whop

Secondary CTA:

> Explore the interactive demo

Trust line:

> Nothing sends without your approval.

## Canonical product vocabulary

- RescueLoop
- Recovery Pulse
- Rescue Queue
- Signals
- Evidence
- Playbooks
- Interventions
- Responses
- Outcomes
- Value Ledger
- Activity
- Loop Notes

Reserve `Loop Score`; do not launch it until methodology is validated.

## Truthful state vocabulary

Use:

- queued;
- approved;
- scheduled;
- provider accepted;
- responded;
- returned;
- outcome observed;
- failed;
- suppressed.

Do not use `delivered` unless delivery itself is verified.

## Student-language prohibition

Student-facing surfaces must never include:

- risk;
- churn;
- revenue;
- rescue target;
- conversion;
- cancellation probability;
- evidence score;
- recovered value.

## Voice behavior

1. State what happened.
2. State the recommendation.
3. Explain why.
4. Make the next action explicit.
5. Separate facts from inference.
6. Avoid praise/confetti around sensitive interventions.

## Avoid

- revolutionary AI;
- explosive growth;
- rescue all churn instantly;
- guaranteed revenue;
- autopilot your community;
- magic;
- effortless income;
- Apple-like or iOS-like claims in customer copy.
