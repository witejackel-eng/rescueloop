# Brand North Star

## Name

**RescueLoop**

Never split it into “Rescue Loop” in product UI, metadata, legal references, or assets.

## Category line

**Activation rescue for Whop creators**

Use this where immediate category comprehension matters: marketplace, onboarding, browser sharing, and early marketing.

## Central promise

> Close the loop before they leave.

## Functional promise

> Find who needs help. Approve the right message. See what changed.

## Brand idea

**The Closing Signal**

A purchase is not progress. RescueLoop notices the weak signal between purchase and first value, gives the creator evidence and control, and observes whether support restored momentum.

## Five pillars

1. **Perceptive** — notices unresolved activation failure.
2. **Respectful** — supports members instead of pressuring them.
3. **Controlled** — the creator sees the reason, message, timing, and outcome.
4. **Evidenced** — every signal and outcome is traceable.
5. **Restorative** — the emotional direction is return, not alarm.

## Personality

Calm, precise, attentive, protective, human, quietly confident.

Never: aggressive, gamified, alarmist, “growth hacker,” robotic, cute, or falsely luxurious.

## Recognition strategy

Recognition must come from repeated, controlled signals:

- the Closing Signal silhouette;
- cream + ink + recovery green;
- Instrument Sans with restrained Instrument Serif;
- evidence-led language;
- calm operational surfaces;
- signal → review → support → observed return diagrams;
- honest attribution language.

The product should be recognizable even when the full wordmark is absent.
