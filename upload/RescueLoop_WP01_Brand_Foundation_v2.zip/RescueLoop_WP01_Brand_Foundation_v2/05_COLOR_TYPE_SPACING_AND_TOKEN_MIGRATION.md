# Color, Typography, Spacing, and Token Migration

## Existing foundation to preserve

The current palette is already strategically correct:

- Canvas `#F4F1EA`
- Canvas Elevated `#F8F6F0`
- Surface `#FCFBF7`
- Ink `#11110F`
- Ink Secondary `#5F5D57`
- Ink Muted `#8D8A82`
- Recovery Green `#147D68`
- Recovery Light `#DCEDE7`
- Signal Amber `#C68A1E`
- Signal Light `#F5E8C9`
- Critical `#B83D34`
- Critical Light `#F0D5D2`
- Information `#3D6B8C`

## Semantic rules

- Green: approval, healthy connection, progress, return, confirmed success.
- Amber: attention or stalled state—not failure.
- Red: destructive action, denied access, failed operation, or genuine data-loss risk.
- Blue: neutral information only.
- Never use color alone to communicate state.
- No gradients in dense product UI.
- Subtle gradients are permitted only for app icons, OG imagery, and highly controlled marketing atmosphere.

## Typography

- Instrument Sans: interface, body, controls, tables, navigation.
- Instrument Serif: major marketing statements and a limited number of editorial empty-state headings.
- JetBrains Mono: counts, currency, rates, timestamps, IDs, rule values, evidence metadata.

Do not add another primary font during WP-01.

## Token hierarchy

1. Primitive.
2. Semantic.
3. Component.
4. State.

Brand assets must consume semantic tokens. Components must not hardcode off-system primary colors.

## Spacing

Canonical scale:

```text
0, 2, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96
```

## Radius

- Base controls: 4–6 px.
- Cards/panels: 6–8 px.
- Large editorial panels: maximum 12–14 px.
- Pills only for status, segmentation, and compact filters.

## Elevation

- Prefer hairline borders.
- Shadows only for transient elevation: menu, popover, drawer, modal.
- No random glow.
- No glassmorphism system.

## Migration rule

Do not layer a second set of variables over the existing `globals.css`. Reconcile naming, create typed exports where useful, update component consumption, then remove obsolete aliases only after usage is proven absent.
