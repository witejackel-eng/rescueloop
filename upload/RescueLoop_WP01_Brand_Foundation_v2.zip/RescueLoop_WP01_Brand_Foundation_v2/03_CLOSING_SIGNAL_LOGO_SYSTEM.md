# Closing Signal Logo System

## Concept

The mark is an incomplete loop whose upper-right gap is resolved by a distinct signal node and short re-entry stroke.

It communicates:

- interruption;
- attention;
- reconnection;
- return to progress;
- completion without coercion.

It must not resemble a refresh icon, loading spinner, recycle mark, chat bubble, lifebuoy, or generic circular arrow.

## Canonical geometry

- One primary outer arc.
- Gap at approximately 1–2 o’clock.
- Signal node at the closing edge.
- Short green return segment leading toward the node.
- Rounded caps.
- Optical center slightly above geometric center.
- No arrowhead at any size.
- No interior decorative stroke in micro sizes.

## Variants

Required canonical variants:

1. `mark-primary` — ink arc + green closing signal, transparent background.
2. `mark-mono` — one-color ink.
3. `mark-reversed` — cream/white on near-black.
4. `mark-micro` — simplified for 16–20 px.
5. `tile-green` — cream mark on recovery-green tile.
6. `tile-ink` — cream mark on near-black tile.
7. `lockup-horizontal` — mark + live text wordmark.

## Minimum sizes

- Micro mark: 16 px.
- Product navigation: 20–24 px.
- Marketing header: 24–30 px.
- Wordmark lockup: minimum 120 px total width.
- Social/avatar: 128 px and above.
- Whop/app listing: 512 px working export.

## Clear space

Minimum clear space equals the signal-node diameter on every side.

## React implementation rule

The production wordmark should be live text styled with the canonical interface font. Do not rely on an SVG `<text>` element for application UI and do not commit font files.

The mark component must support:

- decorative mode: `aria-hidden="true"`;
- meaningful standalone mode: accessible name supplied by the caller;
- size tokens, not arbitrary per-screen geometry;
- primary, mono, reversed, and micro variants;
- no CSS animation inside WP-01.

## Optical QA

Test the mark at:

```text
16, 20, 24, 32, 48, 64, 128, 512 px
```

At 16 px:

- the gap must remain visible;
- the node must not merge into the arc;
- stroke weight must not collapse;
- the silhouette must read without color;
- the mark must remain distinguishable in light and dark browser tabs.
