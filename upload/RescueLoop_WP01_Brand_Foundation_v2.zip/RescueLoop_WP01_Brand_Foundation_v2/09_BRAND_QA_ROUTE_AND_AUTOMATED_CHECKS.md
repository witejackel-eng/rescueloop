# Brand QA Route and Automated Checks

## Brand QA route

Create a protected route such as:

```text
/internal/brand-qa
```

It must be available only in development, test, or authenticated internal contexts. It must not be publicly indexable.

## QA route sections

1. Canonical logo variants.
2. 16/20/24/32/48/64/128 px mark tests.
3. Light, elevated, dark, green, and image backgrounds.
4. Wordmark and lockup clear-space tests.
5. Type hierarchy.
6. Numeric/mono samples.
7. Semantic color matrix.
8. Status examples with icon + text + color.
9. Buttons and focus states.
10. Empty/error/success copy examples.
11. App icon and favicon previews.
12. OG image preview at actual aspect ratio.
13. Student-safe versus forbidden copy.
14. Route-group header/signature variants.
15. Deliberately forbidden examples marked `Do not use`.

## Automated checks

Required tests or scripts:

- every required asset exists;
- raster dimensions match the manifest;
- SVGs have a `viewBox`;
- favicon remains within file-size budget;
- OG/Twitter files remain within build limits;
- one canonical logo module exists;
- no old mark SVG/path remains in known duplicate files;
- no forbidden brand name variants;
- no student-facing forbidden terminology;
- root metadata includes image alt text;
- manifest validates against expected fields;
- internal/private/student-token routes are not inadvertently indexable;
- production source contains no off-system brand hex values outside allowlisted files;
- logo buttons/links have accessible names;
- decorative marks are hidden from assistive technology;
- no font binaries are committed.

## E2E checks

At minimum:

- marketing header shows canonical lockup;
- creator workspace shell shows canonical compact logo;
- demo has canonical logo plus visible Demo indicator;
- student route shows student-safe signature and no forbidden terms;
- internal route shows canonical logo plus Internal context;
- favicon/icon/manifest/OG endpoints respond successfully;
- metadata contains expected title, description, canonical, OG, and Twitter values;
- no hydration or application error overlay.
