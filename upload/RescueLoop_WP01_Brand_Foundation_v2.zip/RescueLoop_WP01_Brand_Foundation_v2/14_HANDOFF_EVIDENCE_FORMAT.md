# Handoff and Evidence Format

The implementer must return this exact evidence structure.

```text
Work package: WP-01 Brand Foundation
Branch:
Base commit:
Final commit:
GitHub Actions run ID:
Overall conclusion:

Canonical logo module:
Canonical asset directory:
Brand QA route:
Metadata strategy:
Manifest path:

Files added:
Files modified:
Files deleted:
Duplicate logo sources removed:

Asset dimensions and file sizes:
Metadata endpoint checks:
Brand-specific tests and counts:
Unit test count:
Contract test count:
Integration test count:
E2E test count:
Production build result:
Security result:

Route groups manually verified:
Viewports verified:
Whop iframe verification:
Accessibility checks:
Performance/asset budgets:
Screenshots/artifacts:

Known limitations:
Tracked debt:
Owner actions required:
Confirmation WP-02 was not started:
```

Do not write “all good” or “complete” without this evidence.
