# Brand QA Route Outline

Route must be internal/development-only.

Recommended sections:

```text
Identity / Micro sizes / Backgrounds / Lockups
Typography / Numeric typography
Semantic colors / Status combinations
Buttons / Focus / Disabled
Route contexts
Student-safe copy
Favicon / App icon / OG previews
Forbidden examples
Automated-test status
```

Use real production components, not separate mock implementations.
