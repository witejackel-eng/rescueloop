// REFERENCE ONLY
import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "RescueLoop",
    short_name: "RescueLoop",
    description: "Activation rescue for Whop creators.",
    start_url: "/",
    display: "standalone",
    background_color: "#F4F1EA",
    theme_color: "#147D68",
    icons: [
      { src: "/brand/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/brand/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
  };
}
