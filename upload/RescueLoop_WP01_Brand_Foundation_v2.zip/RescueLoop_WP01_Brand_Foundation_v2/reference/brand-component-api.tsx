// REFERENCE ONLY — adapt to the existing repository conventions.
export type RescueLoopMarkVariant = "primary" | "mono" | "reversed" | "micro";
export type RescueLoopMarkSize = "xs" | "sm" | "md" | "lg" | number;

export interface RescueLoopMarkProps {
  variant?: RescueLoopMarkVariant;
  size?: RescueLoopMarkSize;
  className?: string;
  decorative?: boolean;
  label?: string;
}

// Contract:
// - decorative=true => aria-hidden=true and no title duplication
// - decorative=false => label is required
// - geometry is defined once
// - no motion is introduced in WP-01
// - wordmark remains live text in product UI
