// REFERENCE ONLY — use validated environment handling from the current repo.
import type { Metadata } from "next";

export const rescueLoopMetadataContract: Metadata = {
  title: {
    default: "RescueLoop — Activation rescue for Whop creators",
    template: "%s — RescueLoop",
  },
  description:
    "Find paying members who never started, approve respectful outreach, and see what changed.",
  openGraph: {
    siteName: "RescueLoop",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
  },
};
