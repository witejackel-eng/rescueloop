# Route-Group Application Matrix

## Public marketing

Identity intensity: high.

- Full lockup in header/footer.
- Serif reserved for the main promise.
- Category line visible early.
- Closing Signal diagrams may be used as abstract illustration.
- Recovery green remains semantic; large fields should favor cream/ink.

## Demo workspace

Identity intensity: medium.

- Same shell identity as connected product.
- Persistent, unmistakable `Demo` indicator.
- Demo data labels must remain visible in screenshots.
- Do not use fake customer/company marks.

## Connected creator workspace

Identity intensity: restrained.

- Compact mark and wordmark.
- Product task hierarchy dominates.
- No slogan repetition.
- Company/course context is clear but does not replace RescueLoop identity.

## Student experience

Identity intensity: quiet.

- Small signature, calm support copy.
- No internal terminology.
- No mention of revenue recovery, churn, risk, rescue queue, signal score, or creator ROI.
- Clear Whop/course continuation path.

## Internal operations

Identity intensity: utilitarian.

- Canonical mark + `Internal` badge.
- Distinct navigation context.
- Never use customer screenshots or marketing language as operational truth.

## Legal/support

Identity intensity: restrained and credible.

- Full text name in document title.
- Compact header mark.
- Clear company/product identity.
- No promotional animation.

## Error, offline, and permission states

- Use the canonical mark sparingly.
- Explain what happened and what remains safe.
- Brand must not overpower recovery instructions.
- Never use celebratory or playful visuals for access, data, or delivery failures.
