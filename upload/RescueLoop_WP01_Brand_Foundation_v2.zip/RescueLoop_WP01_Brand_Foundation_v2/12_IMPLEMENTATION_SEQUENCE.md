# WP-01 Implementation Sequence

## Stage 1 — Preflight and baseline

1. Re-check branch head and WP-00 gate.
2. Confirm clean working tree.
3. Read this ZIP completely.
4. Inventory all current logo components/assets/imports.
5. Inventory metadata, manifest, public assets, and route-group layouts.
6. Capture current desktop/mobile screenshots for comparison.
7. Update the RescueLoop execution ledger with WP-01 start state.

## Stage 2 — Contract and assets

1. Add typed brand contract and token exports.
2. Add canonical SVG source assets.
3. Generate raster exports reproducibly.
4. Validate sizes, file weights, and transparency.
5. Add asset manifest.

## Stage 3 — Canonical components

1. Implement canonical mark/logo/signature components.
2. Add decorative and labelled accessibility modes.
3. Replace old imports systematically.
4. Remove duplicate components only after all replacements pass.

## Stage 4 — Metadata surfaces

1. Add root icon and social image conventions.
2. Add manifest.
3. Make metadata base environment-safe.
4. Add route metadata and canonical/noindex policy.
5. Add metadata tests.

## Stage 5 — Route-group application

Apply identity deliberately to:

- marketing;
- demo;
- connected creator workspace;
- student experience;
- internal operations;
- legal/support;
- error and permission states.

Do not redesign workflows.

## Stage 6 — Copy and naming

1. Add canonical copy dictionary.
2. Replace inconsistent naming.
3. Scan student surfaces for forbidden terminology.
4. Preserve truthful provider and attribution language.

## Stage 7 — Brand QA and checks

1. Build the protected Brand QA route.
2. Add automated asset, metadata, duplication, color, accessibility, and naming checks.
3. Add targeted Playwright coverage.
4. Add visual baselines for the Brand QA route if the project’s visual-regression process is ready; otherwise track with explicit acceptance criteria without deleting coverage.

## Stage 8 — Verification and commit

Run the repository’s exact commands for:

- install/frozen lockfile;
- Prisma generation where required;
- lint;
- typecheck;
- unit;
- contract;
- integration;
- E2E;
- production build;
- security scan;
- brand-specific checks.

Then update the ledger, commit, push, wait for strict CI, and stop before WP-02.
