# RescueLoop WP-01 Brand Foundation v2

A stage-specific implementation package for Zai or another repository-capable engineering agent.

This package includes:

- current repository brand audit;
- brand and verbal identity contract;
- Closing Signal logo system;
- production-starting SVG and PNG assets;
- metadata, icon, manifest, and social-image architecture;
- route-group application rules;
- token migration plan;
- copy and naming dictionary;
- protected Brand QA route specification;
- accessibility, optical, performance, and screenshot QA;
- machine-readable manifests and acceptance gates;
- reference component/metadata contracts;
- stage-specific execution prompt.

The assets are a production starting point. The implementer must perform optical checks at final rendered sizes before public launch.
