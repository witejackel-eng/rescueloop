# Current Repository Brand Audit

## Verified current foundation

The current repository already has several strong ingredients:

- Instrument Sans, Instrument Serif, and JetBrains Mono loaded with `next/font/google`.
- Warm cream canvas, near-black ink, and recovery green semantic palette.
- A central `globals.css` token layer.
- A React logo file at `src/components/brand/logo.tsx`.
- Root metadata with title, description, and basic Open Graph text.
- A product vocabulary including Recovery Pulse, Rescue Queue, Signals, Evidence, Interventions, Outcomes, and Value Ledger.

These are assets to consolidate—not reasons to rebuild the UI.

## Verified gaps

### Logo

The current React mark is an orbit/hourglass-like construction with a dashed outer circle. It does not match the approved **Closing Signal** concept: an incomplete loop resolved by a signal node.

### Metadata

The root layout defines text metadata but lacks a complete production asset system:

- no verified route-specific Open Graph images;
- no complete Twitter image convention;
- no manifest contract;
- no verified Apple touch icon;
- no Whop icon export path;
- no metadata QA tests;
- a hard-coded `metadataBase` that must be environment-safe.

### Asset ownership

There is no proven single canonical `public/brand/` asset directory and no automated duplication guard.

### Route-group identity

Marketing, demo, connected creator, student, and internal operations need deliberately different brand emphasis while remaining unmistakably one product.

### Naming consistency

A source-controlled dictionary is needed to stop drift such as:

- “risk” appearing in student-facing surfaces;
- “delivered” used when only provider acceptance is known;
- “AI retention” replacing the specific category line;
- inconsistent capitalization of Rescue Queue, Recovery Pulse, and Value Ledger.

### Visual QA

The repository needs a Brand QA route that shows:

- every mark variant;
- minimum-size tests;
- background variants;
- type hierarchy;
- semantic colors;
- status combinations;
- metadata assets;
- contrast results;
- intentionally forbidden examples.

## Constraints

- Preserve existing functional UI behavior.
- Preserve the mature product architecture.
- Do not introduce a second token system.
- Do not use Apple trademarks, trade dress, iconography, layouts, or copied product language.
- Do not turn recovery green into decoration.
- Do not add generic AI gradients, glossy 3D objects, robot illustrations, or stock characters.
- Do not commit font files.
