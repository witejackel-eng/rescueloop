# Metadata, Favicon, OG, and Manifest

## Next.js App Router implementation

Use current App Router metadata file conventions rather than hand-inserting duplicate `<link>` or `<meta>` tags.

Recommended root files:

```text
src/app/favicon.ico
src/app/icon.svg or src/app/icon.png
src/app/apple-icon.png
src/app/opengraph-image.png
src/app/opengraph-image.alt.txt
src/app/twitter-image.png
src/app/twitter-image.alt.txt
src/app/manifest.ts
```

Alternative generated `icon.tsx` or `opengraph-image.tsx` implementations are acceptable only when they remain deterministic, build-safe, fast, and use no committed font binaries.

## Root metadata contract

- Title template: `%s — RescueLoop`.
- Default title: `RescueLoop — Activation rescue for Whop creators`.
- Description: specific product function, not generic AI claims.
- Metadata base: derived from a validated server-side app URL, with safe preview/local behavior.
- Open Graph: title, description, image, image dimensions, alt text, site name, type.
- Twitter: card type, title, description, image, alt text.
- Robots: deliberate public/private behavior by route group.
- Canonical URLs for public marketing/legal pages.
- Noindex for demo/private/internal surfaces where appropriate.

## Manifest contract

- Name: `RescueLoop`.
- Short name: `RescueLoop`.
- Description: activation rescue for Whop creators.
- Start URL: `/` unless installed-app requirements justify another route.
- Display: `standalone`.
- Background color: Canvas.
- Theme color: Recovery Green or Canvas based on tested browser behavior.
- 192 and 512 icons.
- Maskable icon only after safe-area testing.

## Asset requirements

### Favicon

- 16, 32, and 48 px tests.
- Simplified micro geometry.
- Visible in light and dark tabs.
- No text.

### Apple touch icon

- 180×180 PNG.
- Opaque background.
- Safe margin.

### PWA/app icons

- 192×192 and 512×512 PNG.
- Opaque field.
- No important pixels near corners.

### Whop icon

- 512×512 working PNG.
- No text.
- Closing Signal occupies approximately 58–64% of the safe area.
- Validate current Whop upload requirements at execution time.

### OG/Twitter

- 1200×630.
- Mark top-left.
- `Close the loop before they leave.`
- `Activation rescue for Whop creators.`
- Signal-to-return diagram.
- No fake metrics, testimonials, customer logos, or security claims.

## Route-specific metadata

At minimum define deliberate metadata for:

- `/`
- `/private-pilot`
- `/legal/privacy`
- `/legal/terms`
- `/demo` or current demo entry
- public support/security pages when present

Connected workspaces, student token routes, and internal operations must not expose private record details in titles, descriptions, Open Graph images, or indexable metadata.
