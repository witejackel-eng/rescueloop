# Implementation Roadmap

## Operating rule

Zai executes one work package at a time. Each package must end with tests, screenshots, changed-file summary, and a commit. Do not request a whole-product rewrite in one prompt.

## Phase 0 — Consolidate and prove (Days 1–3)

- Create canonical integration branch
- Reconcile environment and Whop connection
- Keep mature Prisma schema
- Deploy migration to Neon
- Verify SDK auth and provider calls
- Run tests/build
- Remove temporary local middleware workaround
- Confirm real connected dashboard route

Exit: connected company loads, syncs, and exposes a controlled candidate.

## Phase 1 — Brand operating system (Days 4–6)

- Adopt logo/asset direction
- Lock colors/type
- Consolidate logo components
- Add metadata/favicon/OG
- Refactor tokens
- Audit shell/navigation
- Add brand QA page

Exit: marketing, demo, connected, student, and internal surfaces share one identity.

## Phase 2 — Interaction foundation (Days 7–9)

- Canonical motion tokens
- Reduced-motion behavior
- App shell continuity
- Inspector/drawer patterns
- Button/form/table states
- Loading/error/empty primitives
- Command palette and keyboard model

Exit: interaction primitives pass desktop/mobile/keyboard tests.

## Phase 3 — First-run and first scan (Days 10–12)

- Whop Dashboard View route
- Permission diagnostic
- Mapping
- Sync stages
- Threshold calibration
- First candidate walkthrough
- First-value checklist

Exit: a new creator reaches first reviewable candidate without developer help.

## Phase 4 — Rescue core (Days 13–16)

- Queue
- Evidence inspector
- Draft Review
- Approval/versioning
- Schedule/dismiss/suppress
- Safety rechecks
- Durable send
- Undo where safe

Exit: creator-approved intervention works end to end.

## Phase 5 — Member response and outcome (Days 17–19)

- Student mobile experience
- Blocker response
- Response center
- Stop-after-response
- Course return observation
- Evidence timeline
- Outcome state

Exit: a controlled member response/return appears for the creator.

## Phase 6 — Value and insight (Days 20–22)

- Attribution tiers
- Value Ledger
- Course friction
- Recommendation evidence
- Honest methodology

Exit: outcomes are useful without inflated claims.

## Phase 7 — Pricing and launch (Days 23–25)

- Entitlements
- Usage screen
- Upgrade states
- Trial
- Marketplace icon/screenshots
- Listing copy
- Demo video script
- Support/legal/security review

Exit: unlisted pilot-ready Whop app.

## Phase 8 — Private pilot hardening (Weeks 5–6)

- 5–10 creators
- Instrumentation
- False-positive review
- Sync reliability
- Message quality
- Support and incidents
- Pricing interviews
- Case studies
- Marketplace live decision

## Scope discipline

Do not delay launch for:

- Multi-platform integrations
- Fully autonomous outreach
- Complex multi-company billing
- Predictive churn ML
- A large template marketplace
- Deep custom branding
- Native mobile apps
