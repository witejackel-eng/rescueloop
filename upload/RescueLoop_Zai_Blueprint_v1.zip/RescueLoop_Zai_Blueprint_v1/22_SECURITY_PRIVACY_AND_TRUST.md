# Security, Privacy, and Trust

## Tenant isolation

Every company-scoped read/write must include company authorization and tenant filtering. Test cross-tenant access explicitly.

## Authentication

- Verify Whop user token server-side
- Check company admin access for dashboard views
- Use opaque, expiring, scoped student tokens
- Protect internal operations separately
- Never trust client-supplied company membership

## Secrets

- API keys server-side only
- No `.env` committed
- Validate required variables at startup/deploy
- Rotate compromised secrets
- Separate preview and production credentials

## Webhooks

- Verify signature using supported SDK/mechanism
- Deduplicate
- Store receipt and processing status
- Limit raw-payload access
- Audit replay

## Rate limiting

Production must use persistent/distributed rate limiting where needed:

- Auth attempts
- Student responses
- Message sends
- Bulk actions
- Data exports
- Internal replay
- Public pilot form

Remove temporary no-op local middleware from the production branch.

## Data minimization

Store only fields needed for:

- Eligibility
- Evidence
- Delivery
- Outcome observation
- Support
- Audit
- Billing/usage

Define retention by data class.

## Data rights

- Export request
- Deletion request
- Grace period where appropriate
- Completion audit
- Provider deletion/revocation handling

## Audit

Record:

- Actor
- Tenant
- Action
- Target
- Before/after or version
- Request ID
- Time
- Source
- Result

## AI privacy

- Minimize prompt data
- Do not send unnecessary email or sensitive content
- Document provider retention
- Allow AI drafting to be disabled
- Keep deterministic eligibility independent of AI

## Trust UI

- Permission explanation
- Last sync
- Data freshness
- Automation mode
- Attribution method
- Message version
- Audit history
- Data controls
- Security page

## Incident readiness

- Operational runbook
- On-call owner
- Severity definitions
- Credential rotation
- User notification criteria
- Data-integrity verification
- Post-incident review
