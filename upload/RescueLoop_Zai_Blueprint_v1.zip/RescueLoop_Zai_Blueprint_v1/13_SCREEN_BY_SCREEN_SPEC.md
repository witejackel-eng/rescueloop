# Screen-by-Screen Specification

## 1. Marketing Home

Purpose: explain the category and earn an install/demo action.

Sections:

1. Floating restrained navigation
2. Hero: category, promise, two CTAs, trust line
3. The activation gap
4. Interactive detect-to-return workflow
5. Evidence and creator-control feature
6. Student-side experience
7. Honest outcome attribution
8. Pricing
9. Security/trust
10. FAQ
11. Final CTA
12. Footer

Motion: strongest on hero, increasingly restrained below.

## 2. Onboarding

Five focused stages:

1. Connection and permission check
2. Course/product mapping
3. Initial sync
4. Signal calibration
5. First review

Persistent elements:

- Progress indicator
- Save/resume
- Plain-language data explanation
- Support link
- Exit without losing progress

## 3. Overview

Above the fold:

- Needs review
- Members returned
- Active interventions
- Data freshness

Then:

- Recovery Pulse
- Priority list
- Outcome trend
- Course friction finding
- Recent activity
- System status

Avoid a wall of equally weighted cards.

## 4. Rescue Queue

Primary operational workspace.

Structure:

- Segment tabs
- Search/filter/sort
- List/table
- Persistent or overlay inspector
- Bulk action bar when selected
- Keyboard help

Segments:

- Awaiting review
- Approved
- Scheduled
- Accepted
- Responded
- Returned
- Dismissed

Each row:

- Member identity
- Course
- Signal
- Evidence summary
- Time since trigger
- Previous contact
- Confidence
- Recommended action

## 5. Member Detail / Inspector

Sections:

1. Identity and membership
2. Signal summary
3. Evidence timeline
4. Course progress
5. Current draft
6. Contact history
7. Responses/blockers
8. Outcome attribution
9. Controls: pause, suppress, dismiss, approve

## 6. Draft Review

Make this first-class rather than hidden inside a small panel.

- Member context
- Evidence chips
- Editable subject/title/body
- Tone selector with constrained options
- Variables preview
- Safety checks
- Message length
- Whop preview
- Send timing
- Approve/send
- Version history

AI actions:

- Make shorter
- Make warmer
- Make more direct
- Remove unsupported claim
- Regenerate from evidence

## 7. Members

- Saved views
- Search
- Course/product filters
- Momentum
- Last activity
- Membership status
- Intervention status
- Inspector/detail
- Export subject to entitlement

## 8. Playbooks

Replace campaign complexity with understandable playbooks.

Playbook types:

- Never started
- Early stall
- Mid-course stall
- Near finish
- Cancellation pending
- Renewal approaching

Each playbook:

- Who enters
- Evidence threshold
- Cooldown
- Quiet hours
- Approval mode
- Draft template
- Stop conditions
- Current usage
- Recent outcomes

## 9. Responses

Inbox-like but operational:

- Needs reply
- Blocker selected
- Asked for help
- Resumed without reply
- Closed

No revenue language.

## 10. Outcomes

- Returned members
- Course activity after intervention
- Attribution confidence
- Evidence timeline
- Value Ledger
- Methodology
- Export

## 11. Insights

- Course funnel
- Lesson friction
- Repeated blockers
- Cohort comparison
- Recommendations
- Affected members
- Improvement status

Every recommendation must show evidence and sample size.

## 12. Activity / Audit

- Actor
- Action
- Target
- Before/after
- Time
- Source
- Request/event ID
- Result
- Filter and export

## 13. Integrations

- Whop connection
- Permission status
- Webhook health
- Last sync
- Reconnect
- Data scope
- Future integrations clearly marked, not fake-enabled

## 14. Settings

- General
- Team
- Automation and safety
- Notifications
- Data and privacy
- Plan and billing
- Danger zone

## 15. Student Rescue Experience

Mobile-first.

Sequence:

1. Warm, non-judgmental context
2. Resume course CTA
3. “What got in the way?” options
4. Free text
5. Confirmation
6. Clear privacy/support note

Never expose internal scores or revenue.

## 16. Plan and Usage

- Current plan
- Usage with reset period
- Upcoming limit
- Feature entitlements
- Upgrade
- Billing history when available
- No surprise lockout

## 17. Internal Operations

Prioritize reliability over visual flourishes:

- Organisations
- Pilots
- Sync
- Jobs
- Webhooks
- Dead letters
- Usage
- Data requests
- Incident links
