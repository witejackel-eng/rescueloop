# QA, Acceptance, and Release Gates

## Gate 1 — Repository integrity

- Canonical branch selected
- One Prisma schema
- One Whop integration abstraction
- No duplicate route implementations
- No TypeScript errors ignored
- Lint passes
- Production build passes
- One package-manager lockfile strategy
- No secrets committed

## Gate 2 — Connected flow

With a real test Whop company:

- Install succeeds
- Admin auth succeeds
- Missing permission state works
- Initial sync completes
- At least one real/controlled fixture candidate appears
- Draft can be edited
- Approval is recorded
- Notification provider accepts request
- Duplicate action is prevented
- Outcome event updates record

## Gate 3 — State completeness

Each primary screen has:

- Loading
- Empty
- Populated
- Partial data
- Stale data
- Permission error
- Network/server error
- Plan limit
- Reduced motion
- Mobile state

## Gate 4 — Safety

- Global pause
- Member pause
- Playbook pause
- Cooldown
- Quiet hours
- Stop after response
- Stop after progress
- Opt-out
- Usage entitlement
- Idempotency
- Audit

## Gate 5 — Accessibility

- Keyboard-only completion
- Visible focus
- Focus restoration
- Screen-reader labels
- Form errors
- Target sizes
- Contrast
- Reduced motion
- Zoom/reflow
- No hidden focus under sticky elements

## Gate 6 — Performance

- Route bundle audit
- Core Web Vitals lab checks
- 2,500-member queue test
- 10,000-event outcome test
- No long-task animation
- No avoidable layout shift
- Images/assets sized
- Fonts optimized

## Gate 7 — Visual

- Brand asset consistency
- Token-only colors
- Token-only motion
- No layout shift on hover
- Dense-table alignment
- Whop iframe screenshots
- Mobile screenshots
- Dark/reversed brand assets where used
- Visual-regression baselines approved

## Gate 8 — Commercial

- $29/$59/$119 entitlements enforced
- Upgrade paths preserve work
- Usage counters correct
- Trial behavior defined
- Listing screenshots ready
- Privacy/terms/security current
- Support process ready

## Release levels

### Private alpha
Founder + controlled test company.

### Private pilot
5–10 creators, concierge onboarding.

### Marketplace unlisted
Install link, controlled access.

### Marketplace live
Only after reliability, listing, support, billing, privacy, and incident gates pass.
