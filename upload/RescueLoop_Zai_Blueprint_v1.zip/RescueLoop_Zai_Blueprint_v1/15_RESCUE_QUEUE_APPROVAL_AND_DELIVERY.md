# Rescue Queue, Approval, and Delivery

## Candidate eligibility

For launch, candidate must satisfy:

- Paid/active access exists
- Course mapping exists
- No qualifying start/progress event after threshold
- Not opted out
- Not currently suppressed
- Not within cooldown
- No recent creator/member response
- Organisation and playbook active
- Usage entitlement available
- Data freshness acceptable

## Evidence block

Each candidate shows:

- Access granted at
- Current membership status
- Course activity count
- First/last course interaction
- Trigger rule
- Data freshness
- Previous interventions
- Suppression/quiet-hour status

## Approval states

- Draft
- Awaiting review
- Approved
- Scheduled
- Sending
- Accepted by Whop
- Responded
- Returned
- Closed
- Failed
- Suppressed
- Dismissed

Avoid “Delivered” unless verified.

## Bulk actions

Allowed:

- Approve selected
- Schedule selected
- Dismiss selected
- Apply playbook
- Pause selected

Bulk send requires:

- Clear total count
- Preview/sample
- Safety recheck
- Explicit confirmation
- Progress and partial-failure report
- Idempotency

## Delivery safety

Recheck immediately before send:

- Membership active
- Course still mapped
- No new progress
- No new response
- Not opted out
- No suppression
- Cooldown satisfied
- Quiet hours satisfied
- Organisation active
- Playbook active
- Intervention version current
- Message non-empty
- Recipient/user ID valid
- Usage limit available
- Idempotency key unused
- Whop connection healthy
- Required permissions present

## Failure behavior

- Retry transient failures through durable jobs
- Never duplicate accepted notifications
- Store failure class and provider response
- Surface action to creator only when intervention is blocked
- Dead-letter after bounded attempts
- Allow safe requeue

## Undo

Dismiss and suppress offer Undo. Sending does not.
