# Executive Blueprint

## Product

**RescueLoop** is the member-recovery operating system for Whop creators.

It detects members who have not activated or have stopped progressing, explains why they were flagged, prepares respectful outreach, keeps the creator in control, and measures what happened afterward.

## Category

Do not position RescueLoop as generic “AI retention software.” Own a narrower, clearer category:

> **Activation rescue for Whop creators**

The broader category can become **member recovery**, but the launch wedge must remain paid members who never start.

## Core loop

**Detect → Understand → Approve → Support → Observe → Attribute → Improve**

Every product surface should visibly belong to this loop.

## North-star outcome

**Recovered members who resume meaningful course activity after an approved intervention.**

Secondary outcome: retained recurring revenue, but only when evidence supports it.

## Three product promises

1. **No member falls through silently.**
2. **Nothing is sent without the creator’s control.**
3. **No outcome is exaggerated.**

## Experience goal

The product should feel:

- Immediate without feeling frantic
- Intelligent without feeling mysterious
- Premium without feeling decorative
- Safe without feeling bureaucratic
- Powerful without making the creator learn a complex automation system

## Commercial architecture

### Rescue — $29/month
For solo creators proving the recovery workflow.

### Growth — $59/month
For established creators with multiple courses, team collaboration, deeper cohorts, and more volume.

### Scale — $119/month
For larger Whop businesses needing advanced controls, larger limits, faster processing, auditability, and supervised automation.

## Launch strategy

Do not wait for a giant “complete retention platform.” Launch the narrow workflow that can create an undeniable first win:

1. Connect Whop.
2. Identify never-started paid members.
3. Review the first five.
4. Send one creator-approved message.
5. Detect the first return.
6. show the creator exactly what changed.

## Brand thesis

The recognizable symbol is a loop that is almost closed, completed by a single signal node. It represents the moment a silent member is noticed and brought back into progress.

The brand is not a lifebuoy, alarm, siren, robot, or generic circular arrow.
