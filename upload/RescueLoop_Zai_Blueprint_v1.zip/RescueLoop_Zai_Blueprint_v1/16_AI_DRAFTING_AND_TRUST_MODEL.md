# AI Drafting and Trust Model

## Role of AI

AI reduces writing effort. It does not decide whom to contact without deterministic eligibility and evidence.

## Allowed inputs

- Course title
- Lesson/progress state
- Membership start date
- Known first name
- Creator-approved brand voice
- Selected blocker
- Previous intervention history
- Playbook constraints

## Prohibited invention

The model must not invent:

- Personal history
- Intent
- Emotions
- Financial hardship
- Business results
- Course goals not provided
- Reasons for inactivity
- Guarantees
- Creator availability
- Discounts not configured

## Draft structure

1. Human opening
2. Specific but non-invasive context
3. One simple next step
4. Low-pressure help option
5. Clear sender identity

## Draft evidence UI

Every generated draft stores:

- Model/provider
- Prompt version
- Evidence inputs
- Generated timestamp
- Editor changes
- Approved version
- Approver
- Delivery version

## Tone presets

- Warm
- Concise
- Direct
- Encouraging

Avoid vague personality sliders.

## Safety linter

Before approval:

- Unsupported-claim detector
- Pressure/manipulation language
- Sensitive inference
- Excessive personalization
- Missing sender identity
- Broken variable
- Link validation
- Length
- Duplicate/recent message

## Human control

- Creator can edit all text
- Regeneration never overwrites edits without confirmation
- Show diff between versions
- Approval records exact version
- Any later edit invalidates approval and requires reapproval

## Cost controls

- Cache drafts by evidence + prompt version
- Generate on demand or bounded batch
- Use smaller model for linting/classification
- Track per-organisation AI cost
- Plan entitlements can cap generation volume
