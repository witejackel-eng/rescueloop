# Zai Handoff Protocol

This is not the final execution prompt. It defines how the next prompt must control implementation.

## Every Zai task must include

1. Objective
2. Canonical branch
3. Exact scope
4. Files to inspect first
5. Existing behavior to preserve
6. Required implementation
7. Non-goals
8. Acceptance tests
9. Verification commands
10. Required final report

## Zai must inspect before changing

- Current branch and status
- Relevant routes/components
- Design and motion tokens
- Prisma schema/migrations for backend work
- Existing tests
- Whop provider/contracts
- Documentation that already defines behavior

## Zai change discipline

- One work package per branch/commit
- No unrelated redesign
- No duplicate systems
- No new dependency without justification
- No disabling type/lint/build checks
- No hardcoded secrets
- No fake production data
- No unsupported claims
- No destructive migration without explicit plan
- No silent fallback to mock data in connected routes

## Required final report

- What changed
- Why
- Files changed
- Tests run and exact results
- Build result
- Screens/routes manually checked
- Known limitations
- Screenshots where appropriate
- Commit SHA
- Next recommended work package

## Stop conditions

Zai must stop and report rather than guess when:

- Whop API behavior conflicts with current official docs
- A migration would destroy data
- Two branch implementations conflict
- Required credentials are unavailable
- A permission scope is unclear
- A production send could contact real users unexpectedly
