# Analytics, Outcomes, and Revenue Attribution

## Outcome hierarchy

### Product outcome
Member resumed meaningful progress.

### Engagement outcome
Member opened, replied, selected a blocker, or returned.

### Commercial outcome
A payment or cancellation reversal occurred with defensible association.

## Confidence tiers

### Confirmed
Use only when a direct, verifiable causal or explicit reversal event exists and the methodology supports it.

### Strongly associated
Meaningful course activity occurred after the intervention within a defined observation window.

### Estimated
A commercial value model suggests possible impact but cannot prove causality.

## Display rules

- Never sum tiers into one unqualified value.
- Default ROI uses confirmed value only.
- Show associated and estimated separately.
- Every ledger row links to evidence and methodology.
- Allow creator to exclude disputed rows.
- Store methodology version.

## Core metrics

- Paid members monitored
- Eligible candidates
- Queue review rate
- Draft approval rate
- Notification acceptance rate
- Response rate
- Return-to-course rate
- Time to first return
- Progress after return
- Suppression/opt-out rate
- False-positive/dismissal reason
- Confirmed value
- Strongly associated value
- Estimated value
- Cost per returned member

## Funnel

Monitored → Signaled → Reviewed → Approved → Accepted → Responded → Returned → Meaningful Progress

## Cohorts

- Course
- Product
- Access date
- Playbook
- Signal type
- Message version
- Threshold
- Member tenure

## Product analytics vs creator analytics

Product analytics may track use of RescueLoop. It must not expose member-sensitive payloads to third-party analytics. Use an allowlist and pseudonymous IDs.
