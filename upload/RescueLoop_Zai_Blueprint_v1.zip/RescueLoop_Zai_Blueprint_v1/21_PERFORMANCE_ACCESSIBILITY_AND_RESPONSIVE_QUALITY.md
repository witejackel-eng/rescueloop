# Performance, Accessibility, and Responsive Quality

## Performance budgets

Targets at the 75th percentile in field data:

- LCP: ≤ 2.5s
- INP: ≤ 200ms
- CLS: ≤ 0.1

Internal interaction targets:

- Press feedback: next frame
- Local state update: <100ms perceived
- Queue filter response: <150ms for normal datasets
- Drawer open: 240–320ms
- Route shell remains stable
- No animation-driven long tasks

## Bundle discipline

- Server Components by default
- Client Components only for interaction
- Lazy-load charts, editors, and heavy inspectors
- Avoid shipping marketing canvas code into dashboard routes
- Avoid shipping internal workspace code to creator routes
- Measure bundle by route group
- Replace unused UI dependencies
- One package manager/lockfile after consolidation

## Data performance

- Cursor pagination
- Indexed queue queries
- Avoid N+1
- Batched member/evidence retrieval
- Virtualized rows at scale
- Cached stable reference data
- Stale-while-revalidate for noncritical summaries
- Background jobs for heavy computation

## Accessibility target

WCAG 2.2 AA minimum, with selected AAA practices for focus and target size.

## Control sizes

- Aim for 44×44px for primary touch controls
- Never below 24×24px without sufficient spacing/equivalent action
- Rows can be compact while preserving hit area

## Keyboard

- Logical tab order
- Visible focus
- Focus not hidden by sticky UI
- Skip link
- Table/queue keyboard operation
- Focus restoration after dialogs/drawers
- No keyboard traps

## Focus appearance

- At least a clear 2px perimeter equivalent
- Minimum 3:1 change for strong target
- Never rely on subtle background change only

## Screen reader

- Semantic headings
- Named regions
- Proper table headers
- Status updates via appropriate live regions
- Icon labels
- Descriptive button names
- Charts have textual summaries
- Evidence timelines read chronologically

## Motion

- Respect system reduced-motion preference
- Remove automatic and repetitive movement
- Replace translations/blur with fades
- Pause offscreen animation
- No essential information conveyed only through animation

## Contrast

- Verify all token combinations
- Text, icons, focus, charts, and status
- Never rely on green/red alone

## Responsive acceptance

Test:

- 320×568
- 375×812
- 390×844
- 768×1024
- 1024×768
- 1280×800
- 1440×900
- 1920×1080

Also test inside Whop’s embedded dashboard context.
