# Onboarding and First Value

## Objective

The creator should understand the product, trust its data access, and reach a reviewable candidate quickly.

## Step 1 — Welcome

Copy:

**Find the members who paid but never got started.**

Explain:

- What RescueLoop reads
- What RescueLoop can send
- That nothing sends by default
- How data is protected

## Step 2 — Permission diagnostic

Display each required permission as:

- Available
- Missing
- Needs reauthorization
- Checking

Do not show raw scope names without plain-language explanation.

## Step 3 — Course selection

- Preselect likely course experiences
- Show course title and member count
- Allow “Monitor later”
- Warn when a course lacks required data

## Step 4 — Product/access mapping

- Suggest mappings
- Explain confidence
- Prevent duplicates
- Allow testing before save

## Step 5 — Initial sync

Progress stages:

1. Checking connection
2. Importing courses
3. Importing memberships
4. Reading progress
5. Building first signals
6. Ready for review

Show real progress; use indeterminate state when total is unknown.

## Step 6 — Calibration

Example:

“RescueLoop found 18 paid members with no course activity after 48 hours.”

Creator can change threshold and preview impact.

## Step 7 — First candidate

Use an annotated walkthrough, not a long product tour.

Highlight only:

- Why flagged
- Draft
- Approve/edit
- What happens next

## First-value celebration

After first approved intervention:

- Calm confirmation panel
- “Your first loop is active.”
- Show observation state
- Link to the intervention
- No confetti

## Resume behavior

Onboarding state is durable. Returning users resume at the exact incomplete step.
