# Product Analytics Event Taxonomy

## Rules

- Use a strict allowlist.
- No message body, email, free text, or raw member name in analytics.
- Use pseudonymous company and actor IDs.
- Include product version and route.
- Distinguish demo from connected workspace.
- Include plan tier.
- Respect consent and privacy requirements.

## Funnel events

- `app_view_loaded`
- `onboarding_started`
- `permission_check_completed`
- `course_mapping_saved`
- `initial_sync_started`
- `initial_sync_completed`
- `first_scan_completed`
- `candidate_opened`
- `draft_edited`
- `intervention_approved`
- `intervention_scheduled`
- `notification_accepted`
- `member_response_observed`
- `member_return_observed`
- `first_value_reached`
- `plan_limit_viewed`
- `upgrade_started`
- `upgrade_completed`

## Quality events

- `candidate_dismissed`
- `dismiss_reason_selected`
- `draft_regenerated`
- `safety_check_failed`
- `sync_failed`
- `permission_missing`
- `delivery_failed`
- `undo_used`
- `help_opened`
- `support_contact_started`

## Properties

Common:

- `company_id_hash`
- `plan_tier`
- `workspace_mode`
- `route`
- `source`
- `app_version`
- `session_id`

Candidate:

- `signal_type`
- `course_id_hash`
- `evidence_age_bucket`
- `confidence_bucket`
- `previous_intervention_count`

Outcome:

- `outcome_type`
- `attribution_tier`
- `hours_since_intervention_bucket`
- `playbook_id_hash`
- `message_version_id_hash`

## Success dashboards

- Activation funnel
- Time to first value
- Queue completion
- Draft edit/approval
- Return rate
- False-positive proxy
- Sync health
- Plan conversion
- Customer retention
