# Growth, Whop Marketplace, and Customer Acquisition

## Objective

Make RescueLoop recognizable and trustworthy before relying on broad outbound acquisition.

## Marketplace position

Category: Business & Productivity / Coaching support.

Listing headline:

**Find the members who paid but never started.**

Listing description:

RescueLoop identifies inactive course members, prepares respectful outreach for your approval, and shows who returned—without spam or inflated revenue claims.

## Listing asset sequence

1. Icon: Closing Signal mark
2. Hero screenshot: Rescue Queue
3. Evidence screenshot
4. Draft Review screenshot
5. Student Response screenshot
6. Outcomes/Value Ledger screenshot
7. 60–90 second product video

## Product-led acquisition loop

1. Install
2. First scan
3. First approved intervention
4. First member response/return
5. Outcome card
6. Ask creator for feedback
7. With consent, convert result into case study
8. Referral/install link

## Fast customer plan

### First 10 customers
- Concierge onboarding
- Personally calibrate their first playbook
- Review first 20 candidates with them
- Weekly feedback call
- Measure false positives and time saved
- Do not promise revenue

### First 50 customers
- Standardized onboarding
- In-product first-value checklist
- Short help videos
- Triggered support when sync/permissions fail
- Publish evidence-led case studies

### First 200 customers
- Referral program
- Whop creator partnerships
- Public benchmark content using aggregate/anonymized data
- Playbook templates by creator type
- Upgrade optimization

## Recognizable brand mechanics

- The Closing Signal mark appears at every loop transition.
- “Close the loop” becomes the repeated narrative.
- Recovery green always represents a return or approved progress.
- Outcome cards use a consistent evidence timeline.
- Marketplace screenshots all use the same cream/ink framing.
- Product emails and changelog use the same concise voice.

## Content engine

Topics:

- Why paid members never start
- How to message inactive students without sounding automated
- What a responsible revenue-attribution model looks like
- How course friction appears in progress data
- Creator checklists for the first 48 hours after purchase
- Case studies with transparent methodology

## In-product growth

- Shareable creator-side outcome summary
- Team invite
- Referral after a real positive outcome
- “Powered by RescueLoop” only in appropriate creator/admin contexts
- Never place growth branding in sensitive student communication without clear sender context

## Metrics

- Listing view → install
- Install → permission complete
- Permission complete → first sync
- First sync → first candidate reviewed
- First review → first approved intervention
- Intervention → observed return
- Trial → paid
- Plan expansion
- 30/60/90-day retention
- Support burden
- False-positive rate
