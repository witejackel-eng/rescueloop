# Brand Strategy

## Brand name

**RescueLoop**

The name communicates the product’s job and the repeatable operating loop.

## Category line

**Activation rescue for Whop creators**

Use this in early marketplace and onboarding contexts because it is specific and easy to understand.

## Positioning statement

For Whop creators who lose paying members before they experience value, RescueLoop identifies who needs help, prepares evidence-grounded outreach for creator approval, and measures whether the member returned—without spam or inflated attribution.

## Central promise

> Close the loop before they leave.

## Functional promise

> Find who needs help. Approve the right message. See what changed.

## Brand idea

**The closing signal.**

A member can disappear inside a dashboard as one more row. RescueLoop notices the weak signal and closes the missing connection between purchase and progress.

## Brand pillars

### 1. Perceptive
RescueLoop notices what ordinary reporting leaves unresolved.

### 2. Respectful
The product supports members; it does not pressure or manipulate them.

### 3. Controlled
The creator sees the reason, message, timing, and outcome.

### 4. Evidenced
Every signal and result has visible supporting data.

### 5. Restorative
The emotional tone is a return to progress, not an alarm.

## Brand personality

- Calm
- Precise
- Attentive
- Protective
- Human
- Quietly confident

Not:

- Aggressive
- “Growth hacker”
- Alarmist
- Robotic
- Cute
- Gamified for its own sake
- Overly luxurious

## Verbal identity

### Voice

Short, concrete, and evidence-led.

### Sentence behavior

- Lead with what happened.
- State what RescueLoop recommends.
- Explain why.
- Make the next action clear.
- Avoid generic AI adjectives.

### Good examples

- “12 members paid but have not opened the course.”
- “This draft uses the member’s course, start date, and current progress.”
- “Nothing will be sent until you approve it.”
- “Activity resumed 19 hours after the intervention.”
- “Associated value is shown separately from confirmed value.”

### Avoid

- “Supercharge your retention with revolutionary AI.”
- “Unlock explosive growth.”
- “Rescue all churn instantly.”
- “Guaranteed recovered revenue.”
- “Autopilot your community.”

## Naming architecture

- RescueLoop — company and product
- Rescue Queue — operational queue
- Signals — detected situations
- Evidence — why a signal exists
- Playbooks — repeatable rules and messages
- Interventions — approved outreach actions
- Responses — member replies/blockers
- Outcomes — observed changes
- Value Ledger — attribution record
- Recovery Pulse — overview status
- Activity — audit timeline
- Loop Notes — optional product release notes
- Loop Score — reserved; do not launch until methodology is validated

## Product microcopy principles

1. Use verbs on buttons: Review, Approve, Send, Schedule, Dismiss.
2. Never use “OK” when a specific verb exists.
3. For destructive actions, name the result: “Delete all member data.”
4. Explain waiting states: “Checking 1,248 memberships…”
5. Pair errors with recovery: “Whop access expired. Reconnect to resume syncing.”
6. For automated decisions, show the rule and evidence.
7. Avoid congratulatory confetti for sensitive actions.
