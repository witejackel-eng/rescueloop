# WP-06 — Value and Insights

## Objective
Explain outcomes and course friction without exaggerating causality.

## Required
- Confidence tiers
- Value Ledger
- Methodology
- Evidence timeline
- Course funnel
- Friction map
- Repeated blockers
- Recommendations with sample size
- Dispute/exclude control

## Acceptance
- Tiers never collapse into one headline
- Confirmed ROI uses confirmed value only
- Every recommendation links to evidence
- Demo data remains labeled
