# WP-03 — Onboarding and First Scan

## Objective
Move a newly installed Whop creator from permission check to first reviewable candidate.

## Required
- `/dashboard/[companyId]` entry
- Admin access validation
- Permission diagnostic
- Course/product mapping
- Real sync stages
- Threshold calibration
- Durable resume
- First-candidate walkthrough
- First-value checklist

## Acceptance
- Every permission has remedy
- Refresh does not lose progress
- Sync status is truthful
- Candidate count preview works
- Creator reaches first candidate without developer intervention
