# WP-09 — Hardening

## Objective
Prove reliability, accessibility, performance, and operational readiness.

## Required
- Full test suites
- Real Whop E2E
- Tenant isolation
- Retry/dead-letter
- Webhook replay
- Data export/deletion
- WCAG audit
- Responsive/Whop iframe QA
- Core Web Vitals and bundle audit
- Sentry/PostHog wiring with privacy allowlist
- Incident runbook rehearsal

## Acceptance
- All release gates pass
- No P0/P1 bug
- Private pilot support owner and escalation path exist
- Marketplace-live decision is evidence-based
