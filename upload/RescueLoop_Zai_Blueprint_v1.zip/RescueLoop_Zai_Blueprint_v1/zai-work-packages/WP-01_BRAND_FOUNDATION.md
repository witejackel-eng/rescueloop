# WP-01 — Brand Foundation

## Objective
Implement the Closing Signal identity across metadata, product shell, marketing, student experience, and Whop assets.

## Required
- Canonical logo component
- Favicon/PWA/app icon/OG metadata
- Instrument Sans/Serif + JetBrains Mono
- Color and semantic tokens
- Type/spacing/radius/elevation tokens
- Brand QA route
- Replace duplicate marks and inconsistent naming

## Preserve
- Warm cream/ink/recovery-green identity
- Existing functional UI behavior

## Acceptance
- Mark is clear at 16px
- No duplicate logo source
- No off-system primary colors
- Metadata previews correctly
- All route groups use consistent identity
