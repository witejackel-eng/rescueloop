# WP-05 — Student Response and Outcome

## Objective
Give members a respectful mobile flow and creators a clear response/outcome record.

## Required
- Opaque token flow
- Resume-course action
- Blocker selection
- Free-text response
- Idempotent submission
- Stop-after-response
- Creator Responses workspace
- Progress/return observation
- Evidence timeline

## Acceptance
- Student never sees risk/revenue language
- Token expiry/revocation tested
- Repeat submit cannot duplicate response
- Response pauses relevant automation
- Return event appears in creator workspace
