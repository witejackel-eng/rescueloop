# WP-02 — Interaction Foundation

## Objective
Create the shared interaction quality that makes every later screen feel deliberate.

## Required
- Canonical motion tokens
- Reduced-motion implementation
- Stable connected shell
- Responsive inspector
- Keyboard navigation
- Command palette
- Loading/empty/error/stale/permission primitives
- Optimistic action + undo pattern
- Focus restoration
- Native-scroll rules

## Acceptance
- No global scroll-jacking
- Shell does not remount unnecessarily
- Queue can be operated keyboard-only
- Inspector preserves source context
- Reduced motion removes translation/blur/continuous animation
