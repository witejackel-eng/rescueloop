# Zai Work Packages

These are implementation briefs, not the final Zai prompt.

Run in order:

1. `WP-00_BRANCH_CONSOLIDATION.md`
2. `WP-01_BRAND_FOUNDATION.md`
3. `WP-02_INTERACTION_FOUNDATION.md`
4. `WP-03_ONBOARDING_FIRST_SCAN.md`
5. `WP-04_RESCUE_CORE.md`
6. `WP-05_STUDENT_RESPONSE_OUTCOME.md`
7. `WP-06_VALUE_INSIGHTS.md`
8. `WP-07_PRICING_BILLING.md`
9. `WP-08_MARKETPLACE_LAUNCH.md`
10. `WP-09_HARDENING.md`

Each package must be completed, verified, and committed before the next starts.
