# WP-00 — Branch Consolidation and Production Proof

## Objective
Create one canonical implementation from the mature private-pilot branch while preserving the real connection lessons proven on the clean-start branch.

## Inspect first
- Draft PR #1 and changed files
- Both Prisma schemas
- Whop clients/providers
- Environment schemas
- Migration history
- Sync engines
- CI/test configuration
- Temporary middleware/rate-limit files

## Required
- Create `integration/rescueloop-v1`
- Keep mature domain schema and migration lineage
- Port connection fixes deliberately
- Configure real test Neon and Whop
- Verify company auth and first sync
- Remove permissive temporary workaround
- Run lint, typecheck, unit, integration, E2E subset, build

## Non-goals
- Visual redesign
- New features
- Pricing changes

## Acceptance
- One data model
- One Whop abstraction
- Connected dashboard loads for admin
- Sync is idempotent
- No secret committed
- Build gates are strict
