# WP-08 — Whop Marketplace Launch

## Objective
Prepare an unlisted private-pilot listing that can graduate to live.

## Required
- App icon
- Listing copy
- Five screenshots
- Demo video
- Dashboard and Experience paths
- Support/security/privacy/terms URLs
- Permissions explanation
- Pilot onboarding
- Case-study consent
- Demo honesty labels

## Acceptance
- Install-to-first-scan tested from listing
- Screenshots use consistent brand frame
- No fabricated metrics/testimonials
- Unlisted release can support first 10 creators
