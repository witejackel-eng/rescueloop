# WP-04 — Rescue Core

## Objective
Finish the daily creator workflow: evidence, draft, approval, safe delivery.

## Required
- Paginated Rescue Queue
- Filters/saved state
- Evidence inspector
- First-class Draft Review
- Message versions
- Approval invalidation after edit
- Schedule/dismiss/suppress
- Undo for reversible actions
- Safety recheck
- Idempotent provider send
- Audit trail

## Acceptance
- No message sends without valid approval
- Duplicate request cannot duplicate send
- Provider acceptance is not labeled delivery
- Creator can explain why every member was flagged
- Full workflow works with a controlled Whop account
