# Launch Asset Checklist

## Product identity

- [ ] Primary logo
- [ ] Reversed logo
- [ ] Monochrome logo
- [ ] Favicon 16/32/48
- [ ] Apple touch icon 180
- [ ] PWA icons 192/512
- [ ] Whop app icon
- [ ] Social avatar
- [ ] OG image
- [ ] Twitter/X card image
- [ ] Email header mark
- [ ] Product watermark rules
- [ ] Brand usage page

## Whop marketplace

- [ ] App name
- [ ] One-line description
- [ ] Long description
- [ ] Category
- [ ] Required permissions copy
- [ ] Pricing
- [ ] Five screenshots
- [ ] 60–90 second demo video
- [ ] Support URL
- [ ] Privacy URL
- [ ] Terms URL
- [ ] Security URL
- [ ] Changelog URL
- [ ] Install onboarding tested
- [ ] Dashboard View configured
- [ ] Experience View configured
- [ ] Admin access validation
- [ ] Listing status plan: unlisted → live

## Sales

- [ ] Interactive demo
- [ ] Founder demo script
- [ ] One-page product brief
- [ ] First 10 customer outreach list
- [ ] Pilot onboarding email
- [ ] Support response templates
- [ ] Case-study consent
- [ ] Outcome methodology
- [ ] Pricing FAQ
- [ ] Competitor/alternative positioning

## Product trust

- [ ] Privacy
- [ ] Terms
- [ ] Security
- [ ] Data processing
- [ ] Subprocessor list
- [ ] Data export
- [ ] Data deletion
- [ ] Incident response
- [ ] Status page or operational notice path
- [ ] Support SLA by plan
