# Start Here

## The single most important decision

Do not keep building two RescueLoop products in parallel.

The repository contains:

- A lightweight, recently verified Whop/Neon connection branch: `agent/whop-clean-start`
- A much larger product and backend foundation in draft PR #1: `feat/private-pilot-activation-rescue`
- A polished fixture-driven demo inherited from `main`

The correct implementation base is the mature private-pilot branch, after a controlled reconciliation. The clean-start branch proved that the user's real Whop credentials and Neon database can work, but its simplified Prisma schema and direct REST sync must not replace the more complete domain model by accident.

## Canonical sequence

1. Freeze both branches.
2. Create `integration/rescueloop-v1` from `feat/private-pilot-activation-rescue`.
3. Port only verified connection knowledge, environment values, and any uniquely useful `/live` diagnostics from `agent/whop-clean-start`.
4. Run migration, unit, integration, E2E, typecheck, lint, and production build.
5. Make the connected Whop dashboard route the canonical product.
6. Preserve the fixture demo as a sales/demo mode, clearly labeled.
7. Implement the brand and interaction system before polishing individual screens.
8. Ship the activation-rescue loop before adding broad retention automation.

## What not to do

- Do not merge both Prisma schemas.
- Do not keep direct REST and SDK integrations as competing sources of truth.
- Do not redesign every screen before branch consolidation.
- Do not let a beautiful demo conceal broken connected flows.
- Do not enable unattended messaging by default.
- Do not report estimated value as confirmed revenue.
- Do not use animation to cover latency.
- Do not copy Apple assets, typography, icons, or layouts.

## Definition of the first sellable product

A creator installs RescueLoop in Whop, completes onboarding, sees a trustworthy list of members who paid but never started, opens a member, reviews an evidence-grounded message, edits or approves it, sends it through Whop, observes whether the member returns, and sees the outcome in an honest value ledger.
