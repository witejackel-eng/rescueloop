# Core User Journeys

## Journey 1 — Install to first value

1. Creator installs RescueLoop from Whop.
2. Dashboard view validates company admin access.
3. RescueLoop explains requested permissions in plain language.
4. Creator selects the course(s) to monitor.
5. Creator maps course access/products where needed.
6. Initial sync begins with visible stages.
7. RescueLoop performs the first scan.
8. Creator sees a short calibration summary.
9. Creator reviews the first candidate.
10. Creator edits/approves the first draft.
11. Whop accepts the notification.
12. RescueLoop begins observing outcome signals.

Aspirational time to first reviewable candidate: under three minutes when data size and Whop latency allow.

## Journey 2 — Daily rescue review

1. Creator lands on Overview.
2. “Needs review” is the dominant action.
3. Creator opens Rescue Queue.
4. Keyboard focus begins on the first candidate.
5. Creator sees identity, evidence, course context, prior contact, and draft together.
6. Creator approves, edits, schedules, or dismisses.
7. The row exits with a continuity animation.
8. An Undo action remains available briefly.
9. Focus moves to the next candidate.
10. Queue completion is acknowledged without confetti.

## Journey 3 — Member response

1. Member receives a respectful Whop notification.
2. Deep link opens a mobile-first RescueLoop experience.
3. Member sees course/member-friendly language.
4. Member can resume, select a blocker, or reply.
5. Response is saved idempotently.
6. Creator receives a response item.
7. Existing playbook pauses automatically after response.
8. Creator follows up manually or with an approved response.

## Journey 4 — Outcome attribution

1. RescueLoop observes course activity after intervention.
2. Evidence timeline records the event.
3. Outcome receives confidence tier.
4. Creator sees the member returned.
5. Value Ledger displays associated value separately from confirmed value.
6. Creator can inspect methodology.

## Journey 5 — Course improvement

1. Multiple members choose the same blocker or stall at the same lesson.
2. Insights creates an evidence-backed finding.
3. Creator views affected members and event sample.
4. Creator marks improvement planned/completed.
5. RescueLoop observes whether future cohorts improve.

## Journey 6 — Upgrade

1. Creator reaches a real plan limit.
2. Product explains the limit and current usage.
3. Existing data remains accessible.
4. High-cost/new actions are paused, not silently discarded.
5. Upgrade screen compares only relevant differences.
6. Return path preserves the creator’s previous context.
