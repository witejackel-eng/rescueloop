# Canonical Product Decisions

These decisions prevent the Zai implementation from reopening settled questions.

## D1 — Launch wedge

Paid course members who have not started after a configurable threshold.

Default threshold hypothesis: 48 hours after access is granted. The creator can change it.

## D2 — Human control

Default automation mode: **Manual approval**.

Available later:

- Manual approval
- Approve in batches
- Auto-send only for explicitly enabled, low-risk playbooks
- Global pause
- Per-member pause
- Per-campaign pause
- Stop after response
- Stop after progress

## D3 — Product truth

Never combine confirmed, strongly associated, and estimated value into a single headline number.

## D4 — Canonical workflow language

- Signal
- Evidence
- Rescue Queue
- Draft
- Intervention
- Response
- Return
- Outcome
- Revenue Saved
- Playbook
- Activity

Avoid in student-facing content:

- Risk
- Churn
- Revenue
- Rescue target
- Conversion
- Cancellation probability

## D5 — Route architecture

- Marketing: public
- Demo workspace: fixture data, clearly labeled
- Connected creator workspace: `/dashboard/[companyId]/...` as the Whop Dashboard View convention
- Student experience: `/experiences/[experienceId]/...`
- Internal operations: protected and separate
- API: server only

## D6 — Data architecture

Use the mature provider architecture and official Whop SDK. A REST fallback may exist only behind the same provider contract and must not become a second source of truth.

## D7 — Design identity

Retain the current warm cream, near-black, and recovery-green foundation. Refine it rather than replacing it with a trendy neon SaaS palette.

## D8 — Typography

Canonical system:

- Instrument Sans: product UI and marketing body
- Instrument Serif: brand/editorial display only
- JetBrains Mono: analytical values, IDs, timestamps, and evidence

Reconcile any README or implementation that references Geist as the primary UI font.

## D9 — Motion

Motion must explain state, preserve context, and confirm action. It must not slow task completion.

## D10 — Mobile

The creator dashboard is responsive and fully usable on mobile, but queue review is optimized for desktop/tablet. The student rescue experience is mobile-first.

## D11 — Pricing

Launch with $29 / $59 / $119. Limits are hypotheses until actual usage and Whop notification costs are measured. Entitlements live in code and database, not marketing copy alone.

## D12 — AI

AI drafts from known evidence. It does not invent personal facts, outcomes, or reasons. Every claim is editable and traceable.

## D13 — Brand standard

Apple-level craft means disciplined hierarchy, feedback, continuity, performance, and accessibility. It does not mean copying Apple layouts, marks, naming, iconography, materials, or typography.
