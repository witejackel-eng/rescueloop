# Information Architecture

## Creator workspace navigation

### Primary
1. Overview
2. Rescue Queue
3. Members
4. Playbooks
5. Responses
6. Outcomes
7. Insights

### Secondary
8. Activity
9. Integrations
10. Settings
11. Plan & Usage
12. Help

## Route manifest

### Whop Dashboard View
Use the Whop-recommended dashboard convention:

`/dashboard/[companyId]`

Subroutes:

- `/dashboard/[companyId]/overview`
- `/dashboard/[companyId]/queue`
- `/dashboard/[companyId]/members`
- `/dashboard/[companyId]/playbooks`
- `/dashboard/[companyId]/responses`
- `/dashboard/[companyId]/outcomes`
- `/dashboard/[companyId]/insights`
- `/dashboard/[companyId]/activity`
- `/dashboard/[companyId]/integrations`
- `/dashboard/[companyId]/settings`
- `/dashboard/[companyId]/usage`

Existing `/companies/[companyId]` routes can be preserved during migration with redirects or route-group reuse. Do not duplicate page logic.

### Whop Experience View

- `/experiences/[experienceId]`
- `/experiences/[experienceId]/rescue/[token]`
- `/experiences/[experienceId]/rescue/[token]/blocker`
- `/experiences/[experienceId]/rescue/[token]/complete`

### Public

- `/`
- `/pricing`
- `/security`
- `/privacy`
- `/terms`
- `/demo`
- `/changelog`
- `/help`

### Internal

- `/internal`
- `/internal/organisations`
- `/internal/pilots`
- `/internal/sync`
- `/internal/jobs`
- `/internal/webhooks`
- `/internal/dead-letters`
- `/internal/usage`
- `/internal/data-requests`

## Navigation behavior

- Preserve company context across routes.
- Preserve selected course filter across relevant routes.
- Use URL search parameters for filters that users may share or revisit.
- Use browser-native back/forward.
- Do not replace navigation with client-only hidden state.
- Keep global actions in the top bar: command palette, sync status, notifications, workspace menu.
- Keep page actions in the page header.
- Keep row actions in the row/inspector.
- Avoid three different locations for the same action.

## Responsive structure

### Desktop ≥ 1180px
Persistent left navigation, central workspace, optional right inspector.

### Tablet 768–1179px
Collapsible navigation, full-width content, overlay inspector.

### Mobile < 768px
Bottom or sheet navigation, stacked cards, full-screen detail pages. Student experience remains especially optimized for this range.

## Context hierarchy

Always show:

- Current company
- Current course when filtered
- Current queue segment
- Current data freshness
- Current automation mode
