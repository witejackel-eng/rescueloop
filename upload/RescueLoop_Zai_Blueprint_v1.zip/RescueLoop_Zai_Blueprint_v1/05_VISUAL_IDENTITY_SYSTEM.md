# Visual Identity System

## Visual premise

A warm editorial command center with precise analytical structure.

RescueLoop should look distinct from:

- Generic blue/purple AI dashboards
- Cybersecurity alarm interfaces
- Loud marketing automation tools
- Apple clones
- Dark trading terminals

## Core palette

| Token | Hex | Purpose |
|---|---:|---|
| Canvas | `#F4F1EA` | Primary app background |
| Canvas Elevated | `#F8F6F0` | Secondary zones |
| Surface | `#FCFBF7` | Cards, panels, menus |
| Ink | `#11110F` | Primary text and mark |
| Ink Secondary | `#5F5D57` | Supporting text |
| Ink Muted | `#8D8A82` | Metadata |
| Recovery Green | `#147D68` | Positive actions, active loop |
| Recovery Light | `#DCEDE7` | Positive backgrounds |
| Signal Amber | `#C68A1E` | Attention, stalled signals |
| Signal Light | `#F5E8C9` | Attention backgrounds |
| Critical | `#B83D34` | Destructive and genuine failure only |
| Critical Light | `#F0D5D2` | Critical background |
| Information | `#3D6B8C` | Neutral system information |

## Color rules

- Recovery green is not decorative. It means progress, approval, return, or healthy connection.
- Amber means attention, not failure.
- Red is reserved for destructive actions, denied access, failed delivery, and data-loss risk.
- Never encode status by color alone.
- Marketing can use more near-black sections; the product remains primarily light and calm.
- Avoid gradients inside data interfaces. A subtle gradient is acceptable for the app icon and OG image.

## Typography

### Instrument Sans
Interface copy, navigation, forms, tables, settings, body text.

### Instrument Serif
Marketing hero, major editorial statements, selected empty-state headlines. Never for dense tables or controls.

### JetBrains Mono
Money, rates, counts, timestamps, IDs, rule values, and audit metadata.

## Type scale

- Display XL: 72/72 desktop, 46/48 mobile
- Display L: 56/58 desktop, 38/42 mobile
- H1: 40/44
- H2: 30/36
- H3: 22/28
- Body L: 18/28
- Body: 15/23
- Small: 13/19
- Label: 12/16, medium weight
- Data: 13/18 mono

## Shape language

- Product radius: 6px default
- Large panels: 12px maximum
- Pills only for status, segmentation, and compact filters
- Hairline borders over heavy shadows
- Shadows only for transient elevation: menu, popover, drawer
- No oversized glassmorphism
- No continuous glossy highlights

## Layout language

- 12-column editorial grid for marketing
- Product shell based on stable navigation + flexible workspace
- Dense operational tables with generous row hit areas
- Right-side inspector for queue review
- Bottom sheet on mobile
- Persistent context bar for selected course/campaign
- Sticky headers only when they preserve orientation

## Illustration language

Use abstract system diagrams made from:

- Paths
- Signal nodes
- Evidence cards
- Progress arcs
- Course steps
- Return trajectories

Do not use stock 3D characters or generic robot imagery.

## Logo concept

The primary mark is an incomplete ring whose gap is resolved by a signal node. The visual idea is “a loop brought back into continuity.”

The mark must work:

- At 16px in Whop navigation
- At 32px in the product shell
- At 128px in social avatars
- At 512px in marketplace listings
- In one color
- Reversed on dark
- Without the wordmark

## Asset policy

The SVGs in `assets/brand` are an initial art direction and production starting point. Before public launch:

1. Test at 16, 20, 24, 32, and 48px.
2. Correct optical balance manually.
3. Convert final wordmark lettering to outlines only after the type choice is locked.
4. Export PNG, WebP, and maskable icons.
5. Check Whop’s current listing requirements.
