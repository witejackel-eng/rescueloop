# Motion and Scroll System

## Motion role

Motion has four jobs:

1. Confirm input
2. Explain spatial change
3. Preserve object continuity
4. Draw attention to new state once

It must not delay experienced users.

## Canonical tokens

| Token | Duration | Use |
|---|---:|---|
| instant | 80ms | Color/opacity response |
| press | 120ms | Press compression |
| micro | 160ms | Tooltip, icon, checkbox |
| standard | 240ms | Tabs, small popover, row state |
| panel | 320ms | Drawer/sheet |
| route | 360ms | Local route continuity only |
| reveal | 520ms | Marketing scroll reveal |
| hero | 820ms | Initial marketing composition |
| celebration | 480ms | Rare first-value confirmation |

Easing:

- Standard out: `[0.22, 1, 0.36, 1]`
- Emphasized out: `[0.16, 1, 0.3, 1]`
- Symmetric: `[0.65, 0, 0.35, 1]`

Springs:

- Layout: stiffness 260, damping 28
- Panel: stiffness 300, damping 32
- Segmented control: stiffness 440, damping 38

## Motion rules by component

### Button
- Scale to 0.98 on press
- Do not bounce on release
- Spinner fades in without changing width

### Segmented control
- Shared indicator moves with a spring
- Label colors transition 160ms
- Indicator animation disabled in reduced motion

### Queue row
- Selection background 160ms
- Approval: status changes, row compresses 4px, then exits upward/fades in 220ms
- Next row fills space using layout animation
- Undo restores original position

### Inspector
- Overlay opacity 160ms
- Panel transform 320ms
- Focus moves only after panel is ready
- Closing returns focus to source

### Modal
- Use for contained decisions only
- No zoom-from-center for every dialog
- Destructive confirmation uses fade + slight 8px translation

### Counters
- Animate only on first appearance or meaningful refresh
- Preserve digit width
- Reduced motion: replace instantly

### Charts
- Initial draw optional and under 500ms
- No perpetual animation
- Tooltip follows pointer without spring lag
- Respect reduced motion

## Route transitions

Operational product:

- Do not crossfade entire pages on every route.
- Keep shell fixed.
- Replace only workspace content.
- Prefer a 6–12px translate + fade for major region changes.
- Preserve scroll when navigating between list and item.
- Reset scroll only when route semantics demand a new document.

Marketing:

- Reveal content once.
- Intersection threshold 15–25%.
- Do not animate text line-by-line on every section.
- Pause all canvas/marquee animation when hidden or offscreen.

## Scrolling

- Native scrolling only
- No Lenis/smooth-scroll wrapper in the connected product
- `scroll-behavior: smooth` only for explicit anchor navigation and disabled with reduced motion
- Sticky headers must not obscure keyboard focus
- Horizontal table scrolling shows edge affordances
- Avoid nested scroll regions unless inspector/content separation requires it
- Large queues use windowing/virtualization
- Return to the exact prior scroll position after detail navigation

## Reduced motion

When `prefers-reduced-motion: reduce` is active:

- Replace translations with short fades
- Remove scale/bounce
- Disable marquee and word cycling
- Disable canvas particle movement
- Show final chart state
- Avoid blur animation
- Keep state changes visible

## Performance rules

- Animate transform and opacity
- Avoid height/width animation on large trees
- Avoid layout reads inside animation loops
- Use `requestAnimationFrame` only for true continuous graphics
- Suspend offscreen continuous animation
- Cap marketing canvas density by viewport and device performance
