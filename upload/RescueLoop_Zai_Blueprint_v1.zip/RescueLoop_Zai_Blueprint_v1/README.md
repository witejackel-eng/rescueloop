# RescueLoop — Brand & Product Blueprint v1

**Prepared for:** Aditya / Zai implementation workflow  
**Repository:** `witejackel-eng/rescueloop`  
**Snapshot date:** 2026-08-05  
**Commercial model:** $29 / $59 / $119 per month

This package is a build-grade product, brand, motion, UX, engineering, and launch blueprint for turning RescueLoop into the most trusted member-recovery app for Whop creators.

## Start here

Read these files in order:

1. `00_START_HERE.md`
2. `01_EXECUTIVE_BLUEPRINT.md`
3. `02_REPOSITORY_AND_BRANCH_AUDIT.md`
4. `03_CANONICAL_PRODUCT_DECISIONS.md`
5. `04_BRAND_STRATEGY.md`
6. `05_VISUAL_IDENTITY_SYSTEM.md`
7. `08_INFORMATION_ARCHITECTURE.md`
8. `10_INTERACTION_OPERATING_SYSTEM.md`
9. `11_MOTION_AND_SCROLL_SYSTEM.md`
10. `13_SCREEN_BY_SCREEN_SPEC.md`
11. `25_IMPLEMENTATION_ROADMAP.md`
12. `zai-work-packages/README.md`

## What is inside

- A complete product thesis and category position
- A branch-consolidation strategy based on the actual repository
- Three pricing tiers with machine-readable entitlements
- A distinctive brand system and copy language
- Initial logo, favicon, app icon, social avatar, and OG-image assets
- A route map and screen-by-screen specification
- iOS-grade interaction principles adapted for the web
- Motion, scroll, loading, error, and transition standards
- Onboarding, rescue, approval, delivery, and outcome flows
- Trust, AI, attribution, accessibility, performance, and security rules
- Whop marketplace launch and customer-acquisition system
- A phased implementation backlog for Zai
- Acceptance gates that define “done”

## Important instruction

This ZIP intentionally **does not contain the final Zai execution prompt**. The prompt should be generated only after this blueprint is accepted, and it should execute the work package by package rather than attempting one uncontrolled rewrite.

## Product principle

> Detect the right member. Explain the evidence. Let the creator approve the action. Measure the outcome honestly.

## Craft principle

Aim for Apple-level **clarity, continuity, restraint, feedback, accessibility, and performance**—not an imitation of Apple’s visual trade dress.
