# Interaction Operating System

## Goal

The interface should feel effortless because every action has an understandable result, preserves context, and responds immediately—not because it contains more animation.

## Principles

### 1. Direct manipulation
The object being acted upon should visibly respond. Approving a queue item changes that item, not a distant toast alone.

### 2. Continuity
When a row opens into an inspector, identity and status should remain visually connected. When the inspector closes, return focus to the originating row.

### 3. Immediate feedback
Pointer-down or key-down feedback begins within one frame. Network completion can follow later.

### 4. Reversibility
Dismiss, suppress, bulk approve, schedule, and destructive settings changes require either confirmation or Undo based on severity.

### 5. State visibility
Every operation communicates:

- Started
- Processing
- Accepted
- Completed
- Failed
- Partially completed
- Stale or waiting

### 6. Calm density
Operational screens can be dense, but controls remain separated, labels clear, and primary actions visually singular.

### 7. Progressive disclosure
Show the reason and recommended action first. Advanced evidence, event payloads, and rule internals appear on demand.

## Input behavior

- Full keyboard navigation for queue and tables
- `j` / `k` or arrow keys: previous/next candidate
- `e`: edit draft
- `a`: approve
- `s`: schedule
- `d`: dismiss only when not inside text input
- `/`: focus search
- `⌘/Ctrl + K`: command palette
- `Esc`: close the current transient layer
- Never trap focus
- Display keyboard hints only after keyboard intent is detected or in Help

## Buttons

- Minimum recommended hit area: 44×44 CSS px for primary actions
- Compact table icon controls may visually appear smaller but retain padded hit area
- One primary button per decision zone
- Loading buttons keep width stable
- Disabled buttons explain why through adjacent text or tooltip

## Tables and lists

- Row hover is subtle and does not shift layout
- Selected row has a stable background and left indicator
- Checkbox selection never opens the row
- Clicking identity opens detail
- Row action menus do not change row height
- Virtualize very large lists
- Preserve scroll position after returning from detail

## Drawers and inspectors

Desktop:

- Right-side inspector, 420–520px
- Source row remains visible
- Inspector can be pinned for multi-item review

Mobile:

- Full-screen detail route or bottom sheet
- Browser back closes detail
- Primary action remains reachable without covering content

## Optimistic actions

Use optimistic UI when:

- Action is reversible
- Server rejection is rare
- State can be restored safely

Examples:

- Dismiss
- Mark reviewed
- Pause member
- Toggle non-critical preferences

Do not fake completion for:

- Message delivery
- Payment changes
- Data deletion
- Permission changes
- Bulk sends

## Notifications

- Toasts confirm local action, not serve as the only record
- Critical failures persist in context
- Notification center contains unresolved operational items
- Avoid success toasts for every tiny interaction
- Use “Accepted by Whop” until stronger delivery evidence exists

## Forms

- Validate after blur and submit, not on every keystroke unless format feedback is useful
- Preserve typed values after server errors
- Focus first invalid field after submit
- Explain field-level and form-level errors
- Confirm destructive actions twice when recovery is difficult

## Loading

Use three levels:

1. Immediate control response
2. Local skeleton or progress representation
3. Background completion status

Never block the entire application for a local data fetch.

## Offline and stale data

- Show last successful sync
- Allow read-only access to existing records
- Disable actions requiring freshness
- Provide a reconnect/retry path
- Never silently show stale counts as current

## Interaction anti-patterns

- Scroll-jacking
- Cursor-following decoration in operational screens
- Parallax in tables
- Auto-advancing carousels in product UI
- Permanent pulsing buttons
- Blur-heavy transitions
- Celebratory effects for sensitive outcomes
- Layout shifts on hover
- Fake progress bars
