# Open Questions and Validation Plan

## Pricing

- Is 250 monitored members enough for the $29 buyer?
- Are creators more sensitive to member limits, course limits, or interventions?
- Does $59 become the natural default?
- Is $119 too low for high-volume teams once support/AI costs are known?

Validation: 10 pricing interviews + usage telemetry from private pilots.

## Signal quality

- What threshold produces the best balance between early support and false positives?
- Does “course opened” count as started, or is first meaningful lesson activity required?
- How should free/trial access be handled?

Validation: creator review reasons and dismissed-candidate analysis.

## Messaging

- Do creators prefer drafts inside RescueLoop or a workflow that opens Whop messaging?
- Which tone presets are used?
- What message length drives replies/returns without pressure?

Validation: version/outcome analysis, not just clicks.

## Attribution

- Which Whop events can support confirmed value?
- Should cancellation reversal ever be confirmed without explicit event semantics?
- What observation windows vary by course type?

Validation: event-by-event methodology review.

## Marketplace

- Which category and screenshot receives best install conversion?
- Does “activation rescue” outperform “member recovery”?
- Does the human-control promise increase trust enough to offset less “automation” language?

Validation: listing experiments where Whop permits.

## Product breadth

- Are Insights and Value Ledger needed for purchase, or retention after first win?
- Should Responses be a separate nav item at launch?
- Which connected workspace screens are essential for a 25-day build?

Validation: task completion and feature-use data.

## Brand

- Does the Closing Signal mark remain recognizable at 16px?
- Does the cream/ink identity stand out in Whop’s app store?
- Is “Rescue” language supportive or too alarming for some creators?

Validation: icon recognition and five-second message testing.
