# Design Tokens and Component System

## Token hierarchy

1. Primitive values
2. Semantic tokens
3. Component tokens
4. State tokens
5. Motion tokens

Components must not hardcode arbitrary colors or durations.

## Spacing scale

`0, 2, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96`

Most product spacing uses 4, 8, 12, 16, 24, and 32.

## Elevation

- Level 0: canvas
- Level 1: surface with hairline
- Level 2: popover/menu with modest shadow
- Level 3: modal/sheet with stronger shadow
- No elevation represented by random blur/glow

## Required component families

### Navigation
- App shell
- Company switcher
- Primary nav
- Mobile nav
- Breadcrumb/context bar
- Command palette

### Data
- Metric card
- Evidence card
- Status pill
- Queue row
- Member row
- Activity item
- Timeline
- Data table
- Filter bar
- Saved view
- Empty state
- Skeleton

### Decision
- Draft editor
- Message preview
- Evidence panel
- Approval bar
- Schedule control
- Suppression control
- Bulk action bar
- Confirmation dialog
- Undo toast

### Feedback
- Inline error
- Permission state
- Sync state
- Progress stage list
- Toast
- Notification center
- Partial-completion banner

### Commercial
- Plan card
- Usage meter
- Upgrade panel
- Feature comparison
- Trial state
- Limit-reached state

## Component-state matrix

Every interactive component must define:

- Rest
- Hover
- Focus-visible
- Pressed
- Selected
- Disabled
- Loading
- Success
- Warning
- Error
- Reduced-motion
- High-contrast compatibility

## Icon rules

- Lucide can remain the product icon set
- 1.75–2px stroke based on size
- Never mix filled and outline styles without semantic purpose
- Icon-only buttons require accessible labels
- Brand mark is never replaced by a generic refresh/loop icon
