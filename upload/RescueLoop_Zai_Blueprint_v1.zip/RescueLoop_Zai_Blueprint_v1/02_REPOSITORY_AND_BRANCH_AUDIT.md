# Repository and Branch Audit

## Repository snapshot

Repository: `witejackel-eng/rescueloop`  
Default branch snapshot: `main` at `472dfc917e40cc19a5834c180bf7cb5d4c394aff`

### Branch A — `agent/whop-clean-start`

Verified in the user’s environment:

- Whop API authentication works.
- The configured Whop company and app IDs work.
- Neon PostgreSQL is reachable.
- Prisma client generation and schema push work.
- A lightweight sync writes courses, lessons, members, memberships, enrollments, sync runs, and basic risk detections.
- `/live` provides a database-backed diagnostic workspace.
- `/api/sync/status`, `/api/sync/whop`, and a local manual sync route exist.

Strengths:

- Simple and proven against real credentials.
- Useful diagnostic path.
- Small surface area.

Limitations:

- Direct REST integration rather than the mature provider/official-SDK architecture.
- Simplified domain model.
- No full intervention, message, outcome, team, billing, audit, webhook, or durable job system.
- Branch contains only a fraction of the product.

### Branch B — `feat/private-pilot-activation-rescue` / draft PR #1

Repository comparison shows this branch and the clean-start branch have **diverged**. At the audit point it was 47 commits ahead and 11 behind the clean-start branch.

Implemented or scaffolded in this branch:

- Official Whop SDK architecture
- Company/admin authorization
- Standard Webhooks verification
- Provider contracts and fixture/Whop implementations
- Durable Inngest processing
- Transactional outbox and dead-letter concepts
- Opaque student access tokens
- Delivery safety checks
- Conservative attribution engine
- Plan definitions and usage enforcement
- Full PostgreSQL migration
- Connected company routes
- Student rescue experience
- Internal operations workspace
- Marketing, demo, connected, and student route groups
- Unit, contract, integration, E2E, visual, and performance test scaffolding
- Data lifecycle, incident, security, scale, sync, and operations documentation

Strengths:

- Correct product depth and domain language.
- Better production architecture.
- Strong separation between fixture demo and connected workspace.
- Mature route and feature coverage.
- Existing $29/$59/$119 plan definitions.
- Explicit trust and safety model.

Risks:

- Draft PR states that full real-credential and real-database verification was incomplete when written.
- CI and all tests need fresh verification against the current branch.
- Observability integrations are scaffolded but not fully wired.
- Large branch size increases merge and regression risk.
- UI breadth may exceed the validated launch wedge.
- Some documentation and code disagree on typography.
- The existing logo is conceptually relevant but not yet distinctive enough for a category-defining brand.

## Canonical reconciliation strategy

Create a new branch from the mature private-pilot branch:

`integration/rescueloop-v1`

Port from clean-start only:

- Confirmed environment-variable names and setup knowledge
- Proven Neon direct/pooled connection strategy
- Useful connection-status diagnostics
- Useful safe local sync tooling
- Any bug fixes discovered during real Whop calls

Do not port blindly:

- The lightweight Prisma schema
- Duplicate models
- Parallel REST synchronization
- Temporary no-op rate-limit code
- Any local untracked middleware workaround

## Repository rules after consolidation

- One Prisma schema
- One migration history
- One Whop client/provider abstraction
- One connected dashboard route convention
- One design-token source
- One motion-token source
- One logo component
- One plan-entitlement source
- One analytics-event allowlist
- No build configuration that ignores TypeScript failures
- No committed `.env`
- No demo claim presented as real customer data

## Product surface inventory

### Already designed or represented

- Marketing site
- Overview
- Rescue Queue
- Students
- Campaigns and campaign editor
- Insights
- Value Ledger
- Settings
- Onboarding
- Student rescue experience
- Connected company workspace
- Responses
- Audit
- Sync
- Usage
- Internal operations
- Legal pages
- Whop webhook/API routes

### Must be refined or added

- Unified first-run experience inside Whop
- Creator draft-review workspace as a first-class screen
- Evidence panel with plain-language explanations
- Reversible optimistic actions and undo
- Plan/billing experience tied to entitlements
- First-value checklist
- Product-wide loading, zero, stale, partial-data, and permission states
- Notification preference center
- AI provenance and editable-source controls
- Message experiment/version history
- Outcome timeline on member profile
- Cross-device interaction QA
- Marketplace listing asset set
- In-product referral and case-study capture
- Release notes and changelog
- Help center and contextual guidance
