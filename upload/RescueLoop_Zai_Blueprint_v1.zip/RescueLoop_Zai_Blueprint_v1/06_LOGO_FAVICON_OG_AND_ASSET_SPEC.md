# Logo, Favicon, App Icon, and OG Asset Specification

## Primary mark

Concept: **Closing Signal**

Construction:

- Outer ring: 270°–300° arc
- Intentional gap at upper-right
- Signal node sits at the closing edge
- Short inward return stroke suggests re-entry into progress
- No arrowhead at favicon size
- Optical center slightly above geometric center

## Clear space

Minimum clear space equals the signal-node diameter on all sides.

## Minimum sizes

- Mark on screen: 16px minimum
- Mark in product navigation: 20–24px
- Wordmark lockup: 120px wide minimum
- Print minimum: 7mm

## Color variants

1. Ink mark on Canvas
2. Canvas mark on Ink
3. Recovery Green mark on Canvas
4. Single-color black
5. Single-color white

## Favicon

- High-contrast Recovery Green tile
- Canvas/cream loop mark
- No wordmark
- Simplified stroke widths
- Test browser light/dark tab environments

Exports:

- `favicon.svg`
- `favicon-16.png`
- `favicon-32.png`
- `favicon-48.png`
- `apple-touch-icon-180.png`
- `icon-192.png`
- `icon-512.png`

## Whop app icon

- 512×512 PNG minimum working export
- Mark occupies approximately 62% of the safe area
- Green or near-black field
- No small text
- Distinct silhouette
- Avoid placing important pixels at extreme corners

## OG image

Master: 1200×630.

Structure:

- Brand mark top-left
- “Close the loop before they leave.”
- Functional line: “Activation rescue for Whop creators.”
- A simple signal-to-return diagram
- High contrast
- No fabricated metrics, logos, testimonials, or claims

## Screenshot system

Every marketplace screenshot should use:

- Same 24px outer frame
- One clear headline
- One product proof
- One restrained callout
- Real or clearly marked demo data
- Consistent browser/window treatment

Recommended five screenshots:

1. “See who paid but never started.”
2. “Review every message before it sends.”
3. “Understand the evidence behind every signal.”
4. “See who returned after support.”
5. “Measure value without inflated attribution.”

## Assets included

See:

- `assets/brand/rescueloop-mark-primary.svg`
- `assets/brand/rescueloop-mark-mono.svg`
- `assets/brand/rescueloop-lockup.svg`
- `assets/brand/favicon.svg`
- `assets/brand/app-icon.svg`
- `assets/brand/social-avatar.svg`
- `assets/brand/og-image.svg`
- `assets/brand/exported/`
