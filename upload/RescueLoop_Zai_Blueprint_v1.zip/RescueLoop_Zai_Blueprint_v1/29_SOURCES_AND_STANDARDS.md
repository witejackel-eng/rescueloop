# Sources and Standards

These sources ground the blueprint. Recheck them during implementation because platform documentation can change.

## Whop — official

- App Views  
  https://docs.whop.com/developer/guides/app-views  
  Used for Dashboard View, Experience View, route conventions, and company access expectations.

- Authentication  
  https://docs.whop.com/developer/guides/authentication  
  Used for admin access validation in dashboard apps.

- Quickstart  
  https://docs.whop.com/developer/api/quickstart  
  Used for server-side API-key handling and official SDK direction.

- Update app API  
  https://docs.whop.com/api-reference/apps/update-app  
  Used for listing metadata fields such as name, description, icon, paths, and live/unlisted status.

- Whop App Store  
  https://docs.whop.com/whop-apps/whop-app-store  
  Used for marketplace context.

## Apple Human Interface Guidelines — official

- Design Principles  
  https://developer.apple.com/design/human-interface-guidelines/design-principles  
  Used for purpose, flexibility, preserving context, and platform intentionality.

- Motion  
  https://developer.apple.com/design/human-interface-guidelines/motion  
  Used for motion as feedback/instruction and system-consistent behavior.

- Accessibility  
  https://developer.apple.com/design/human-interface-guidelines/accessibility  
  Used for familiar interactions, control sizes, cognitive simplicity, and Reduce Motion behavior.

- Reduced Motion evaluation criteria  
  https://developer.apple.com/help/app-store-connect/manage-app-accessibility/reduced-motion-evaluation-criteria  
  Used for disabling depth/parallax/blur motion when reduced motion is requested.

## W3C — official

- WCAG 2.2  
  https://www.w3.org/TR/WCAG22/

- Target Size (Minimum)  
  https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum

- Focus Appearance  
  https://www.w3.org/WAI/WCAG22/Understanding/focus-appearance.html

## Web performance — Google web.dev

- Web Vitals  
  https://web.dev/articles/vitals

- Core Web Vitals thresholds  
  https://web.dev/articles/defining-core-web-vitals-thresholds

- Optimize INP  
  https://web.dev/articles/optimize-inp

## Repository evidence

- `main` and `agent/whop-clean-start`
- Draft PR #1: `feat/private-pilot-activation-rescue`
- Repository README, Prisma schema, motion tokens, plan definitions, brand logo, connected routes, provider architecture, and test/document inventory as inspected on 2026-08-05.
