# Positioning, Messaging, and Copy System

## Homepage message hierarchy

### Eyebrow
Activation rescue for Whop creators

### Hero
**Close the loop before they leave.**

### Supporting line
RescueLoop finds paying members who never started, prepares respectful outreach for your approval, and shows what changed after you reached out.

### Primary CTA
Install on Whop

### Secondary CTA
Explore the interactive demo

### Trust line
Nothing sends without your approval.

## Problem framing

Do not frame members as “leaks” in the first screen. Lead with silent failure of activation:

> A purchase is not progress. RescueLoop finds the people who paid but never reached their first win.

Revenue language can appear after the human problem is clear.

## Feature messages

### Signals
Know who needs attention before they disappear.

### Evidence
See the exact activity, timing, and rule behind every recommendation.

### Draft Review
Edit and approve each message in one calm workspace.

### Student Response
Give members a respectful way to explain what blocked them.

### Outcomes
See who returned, what they did, and how confidently value can be attributed.

### Course Insight
Turn repeated blockers into course improvements.

## Pricing messages

### Rescue — $29
Start saving the members you already earned.

### Growth — $59
Run recovery across more courses, members, and teammates.

### Scale — $119
Operate member recovery with higher volume, deeper controls, and supervised automation.

## Empty-state pattern

1. State what the space is for.
2. Explain why it is empty.
3. Offer the next action.
4. Avoid illustrations that distract from setup.

Example:

**No members need review right now.**  
RescueLoop will add a member here when a configured signal has enough evidence.  
Button: Review signal rules

## Error pattern

**Sync paused because Whop access changed.**  
No new data has been imported since 4:32 PM. Existing records are safe.  
Buttons: Reconnect Whop · View sync log

## Success pattern

**Message accepted by Whop.**  
We will watch for a response or new course activity.  
Action: View intervention

Do not say “delivered” unless delivery is verified.
