# Notifications, Webhooks, and Background Jobs

## Webhooks

- Verify using Whop’s supported Standard Webhooks/SDK mechanism
- Store receipt before processing
- Deduplicate by webhook ID
- Preserve raw payload securely for limited retention
- Process asynchronously
- Track status and attempts
- Dead-letter irrecoverable events
- Provide internal replay with authorization and audit

## Synchronization

- Initial full sync
- Incremental sync
- Periodic reconciliation
- Cursor/checkpoint storage
- Batch processing
- Per-company locking
- Resumable failures
- Stale-data detection
- Provider rate-limit awareness

## Outbox

Business transaction and outbound job creation occur atomically.

States:

- Pending
- Claimed
- Completed
- Retry
- Dead letter

## Notification semantics

Store separate timestamps for:

- Draft created
- Approved
- Scheduled
- Provider request started
- Provider accepted
- Response observed
- Progress observed
- Closed

## Creator notifications

- Candidate requires review
- Member replied
- Member returned
- Sync failure
- Permission changed
- Plan limit approaching
- Delivery blocked
- Repeated course friction found

Allow digesting and channel preferences.

## Student contact safeguards

- Quiet hours
- Maximum messages per period
- Cooldown
- Stop after response
- Stop after progress
- Opt-out
- Organisation pause
- Per-member pause
- Sensitive wording rules
